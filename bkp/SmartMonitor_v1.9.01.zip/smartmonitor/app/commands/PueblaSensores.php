<?php

use App\Models\SensoresRegistros;
use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class PueblaSensores extends Command {

	protected $name = 'pueblasensores';
	protected $description = 'Puebla tabla sensores registros';
	protected $sensoresRegistros;


	public function __construct()
	{
		parent::__construct();

		$this->sensoresRegistros = new sensoresRegistros();
	}

	public function fire()
	{
		$this->info('Inicio: '.date('Y/m/d H:i:s', time()));
		
		$id = $this->argument('arg1');
		$min = $this->argument('arg2'); 
		$max = $this->argument('arg3');

		//Punto condenzacion
		if ($id == 'PCON01' || $id == 'PCON01' || $id == 'PCON03')
			$min = $min * -1;

		$this->generaRegistro($id,$min,$max);

		$this->info('Fin: '.date('Y/m/d H:i:s', time()));
		$this->info('-------------------------------------');
		$this->info('');
	}

	public function generaRegistro($id,$min,$max)
	{
		$registro = rand($min,$max);

		//Apertuar de Puertas
		if ($id == 'PRTA01' || $id == 'PRTA02')
			$registro = ($registro == 2) ?  -10 : -20;


		$add = $this->sensoresRegistros->addregister($id,$registro);
		
		$this->info($add);
	}

	protected function getArguments()
	{
		return array(
			array('arg1', InputArgument::REQUIRED,null),
			array('arg2', InputArgument::REQUIRED,null),
			array('arg3', InputArgument::REQUIRED,null),
		);
	}

}
