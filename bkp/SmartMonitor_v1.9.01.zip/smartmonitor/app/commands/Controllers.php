<?php

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use App\Models\SensorsRegistersHistory;
use App\Models\Sensors;
use App\Models\SensoresRegistros;
use App\Controllers\SensorController;


class Controllers extends Command {

	protected $name = 'controllers';
	protected $alertController;
	protected $sensorController;
	private $alertsDispatcherController;
	private $sensorRegistersHistory;
	private $sensoresRegistros;
	private $sensors;
	private $action;
	private $idError;


	public function __construct()
	{
		parent::__construct();
		$this->alertsDispatcherController = App::make('AlertsDispatcherController');
		$this->sensorRegistersHistory = new SensorsRegistersHistory();
		$this->sensoresRegistros = new SensoresRegistros();
		$this->sensors = new Sensors();
		$this->sensorController = App::make('SensorController');
	}


	public function fire()
	{
		$this->info('##########################################################');
		$this->info('           Smart Monitor: Controllers '. Config::get('app_globals.version'));	
		$this->info('##########################################################');
		$this->action = $this->argument('arg1');
		$this->idError = $this->option('idError');

		switch ($this->action) {
			case 'alerts':
					$this->putAlerts();
				break;
			case 'historic':
					$this->moveToHistoric();
				break;

			case 'integritySensors':
					$this->deleteSensorBatch();
				break;

			case 'alertNewSensor':
					$this->alertNewSensor();
				break;

			default:
				break;
		}
		
	}


	private function putAlerts()
	{
		$this->info("\n----------------------------------------------------------");
		$this->info('Inicio proceso verificacion de Alertas: '.date('Y/m/d H:i:s', time()));	
		$this->info('----------------------------------------------------------');

		$response =  $this->alertsDispatcherController->configAlertsAllSensors();

		foreach ($response as $value) {
			$this->error('ALERTA');
			$this->info($value);
		}
		$this->info("\n----------------------------------------------------------");
		$this->info('Fin proceso verificacion de Alertas: '.date('Y/m/d H:i:s', time()));
		$this->info('----------------------------------------------------------');
	}

	/*###### Version 1.9.0 ######*/
	private function deleteSensorBatch()
	{
		$this->info("\n----------------------------------------------------------");
		$this->info('Inicio proceso integridad tablas Sensores: '.date('Y/m/d H:i:s', time()));	
		$this->info("----------------------------------------------------------\n");

		$response =  $this->sensors->deleteSensorBatch();

		if ($response == 1) 
			$this->comment(Config::get('app_texts.integritySensors'));	
		else
			$this->error($e);
		
		$this->info("\n----------------------------------------------------------");
		$this->info('Fin proceso integridad tablas Sensores: '.date('Y/m/d H:i:s', time()));
		$this->info('----------------------------------------------------------');
	}

	
	private function moveToHistoric()
	{
		$this->info("\n-----------------------------------------------");
		$this->info('Inicio proceso historico: '.date('Y/m/d H:i:s', time()));	
		$this->info('-----------------------------------------------');

		$response = $this->sensoresRegistros->getMaxIdSensor();

		if ($response->count() > 0) {
		
			foreach ($response as $key => $value) {
			$ids[] = $value->id;
			}
		
			$response = $this->sensorRegistersHistory->putHistRegisters($ids);

			$this->comment("$response registros procesados");	
		}
		
		$this->info("\n-----------------------------------------------");
		$this->info('Fin proceso historico: '.date('Y/m/d H:i:s', time()));
		$this->info('-----------------------------------------------');
		$this->info('');
	}


	protected function getArguments()
	{
		return array(
			array('arg1', InputArgument::REQUIRED,null),
		);
	}

	protected function getOptions()
	{
		return array(
			array('idError', '', InputOption::VALUE_REQUIRED, null, null),
		);
	}

}
