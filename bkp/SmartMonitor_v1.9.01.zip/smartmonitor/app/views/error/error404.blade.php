<!DOCTYPE html>
<html lang="en-us">
	<head>
		<meta charset="utf-8">
		 {{ HTML::style('css/font-awesome.min.css'); }}
	</head>
	<body>
		<h2 class="font-xl text-center"><strong><i class="fa fa-fw fa-warning fa-lg text-warning"></i> Pagina <u>No</u> Encontrada</strong></h2>
		<h3 class=" text-center"><strong>Contacte al administrador del sistema</h3>
	</body>

</html>