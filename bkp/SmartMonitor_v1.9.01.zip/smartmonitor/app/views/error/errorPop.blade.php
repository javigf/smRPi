<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    {{ HTML::style('css/font-awesome.min.css'); }}
    {{ HTML::style('css/smartadmin-production_unminified.css'); }}
</head>
<body>
<div class="alert alert-danger">
     <button class="close" data-dismiss="alert">×</button>
    <i class="fa-fw fa fa-times"></i>
    <strong>Error!</strong> Consulte a su administrador..
</div>

        
</body>
</html>



