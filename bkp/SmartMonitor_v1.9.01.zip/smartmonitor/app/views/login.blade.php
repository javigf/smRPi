<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="utf-8">
        
        <title> Smart Monitor </title>
        <meta name="description" content="Monitoreo Remoto Datacenter">
        <meta name="author" content="Green Net Site">

        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

        {{ HTML::style('css/bootstrap.min.css'); }} 
        {{ HTML::style('css/font-awesome.min.css'); }}
        {{ HTML::style('css/gns_smartmonitor.css'); }}

        <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
        <link rel="icon" href="img/favicon.ico" type="image/x-icon">

    </head>
    <body id="login" class="animated fadeInDown">
        <header id="header">
            <div class="col-lg-offset-1" >
                <span id="logo">{{ HTML::image('img/logo_link.png', 'SmartMonitor'); }}</span>
            </div>
        </header>

        <div id="main" role="main">

            <div id="content" class="container">

                <div class="row">
                    <div class="col-lg-12">
                        <div class="col-lg-4">
                            <div class="pull-left">
                                {{ HTML::image('img/logo.png', 'SmartMonitor'); }}
                                <br><br>
                                <h2 class="paragraph-header txt-color-red">Sistema integral de monitoreo ambiental.</h2>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <br><br>
                             {{ HTML::image('img/sm.png', 'Diseño responsable', array('class' => 'pull-right display-image', 'width' => '400px')); }}
                        </div>

                    <div class="col-lg-4">
                        <div class="well no-padding">
                            
                            {{ Form::open(array('url' => '/login', 'id' => 'login-form', 'class' => 'smart-form client-form')); }}
                                <header>
                                    @if(Session::has('mensaje_error'))
                                        <strong class="text-danger ">{{ Session::get('mensaje_error') }}</strong>
                                    @else 
                                        Ingresar al sistema
                                    @endif
                                 </header>
                                <fieldset>
                                    <section>
                                        {{ Form::label('usuario', 'Nombre de usuario', array('class' => 'label')); }}
                                        <label class="input"> <i class="icon-append fa fa-user"></i>
                                            {{ Form::text('username', Input::old('username')); }}
                                            <b class="tooltip tooltip-top-right"><i class="fa fa-user txt-color-teal"></i> Por favor ingrese su usuario</b></label>
                                    </section>
                                        
                                    <section>
                                        {{ Form::label('clave', 'Clave', array('class' => 'label')); }}
                                        <label class="input"> <i class="icon-append fa fa-lock"></i>
                                            {{ Form::password('password'); }}
                                            <b class="tooltip tooltip-top-right"><i class="fa fa-lock txt-color-teal"></i> Ingrese su clave</b> </label>
                                    </section>
                                </fieldset>
                                <footer>
                                     {{ Form::submit('Enviar', array('class' => 'btn btn-primary')) }}              
                                </footer>
                            {{ Form::close() }}
                        </div>

                    </div>

                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <h5 class="about-heading">Acerca de SmartMonitor</h5>
                                <p class="text-justify">
                                    Link Solutions, una empresa 100% Argentina , dedicada al desarrollo de tecnologías, presenta <strong>SmartMonitor</strong>, una plataforma de monitoría, donde vincula una interfaz amigable e intuitiva, dinámica y adaptable a las necesidades del cliente con un hardware sólido, robusto y altamente eficiente en el consumo de energía.<br>
                                    El desarrollo es totalmente propio, lo que nos permite tener todo el know-how y los equipos de trabajo para entregarle al cliente el producto exacto para cada necesidad. 
                                    Con mínimos requerimientos de infraestructura, ud. puede tener toda la información que lo ayuda a tomar decisiones rápidas y precisas.<br>
                                    <strong>SmartMonitor</strong> nace de la necesidad del mercado de la industria tecnológica como una herramienta de monitoreo económica , fliexible. ágil,  amigable y por sobre todo extensible. 
                                </p>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                <h5 class="about-heading">Acerca de LinkSolution</h5>
                                <p class="text-justify">
                                    <strong>LINKSOLUTION</strong> persigue la máxima calidad en los servicios y productos ofrecidos, por lo cual el control estratégico de proyectos se orienta permanentemente a la excelencia y a la satisfacción de cada cliente, compatibilizando el conocimiento, la metodología y la experiencia, con su adecuado feedback.<br><br>
                                    Somos un equipo de profesionales con amplios conocimientos y experiencia en el mercado de Servicios de Tecnología y Outsourcing. Estas virtudes, sumadas al partnership y alianzas estratégicas con empresas de tecnología de primer nivel, nos permiten brindar a su empresa, un Servicio con un valor agregado diferencial.
                                </p>
                            </div>
                        </div>

            </div>

        </div>

    </body>
</html>
