<!DOCTYPE html>
<html lang="es-ES">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<p><h3>Smart Monitor: Alarma generada por el sensor: <strong>{{ $description }}</strong></h3></p>
		<h4>Con los siguientes datos:</h4>
		<div>
			<p><em>Sensor:</em> {{ $sensor }}</p>
			<p><em>Valor:</em> {{ $val }}</p>
			<p><em>Míninimo:</em> {{ $min }}</p>
			<p><em>Máximo:</em> {{ $max }}</p>
			<p><em>Descripción:</em> <strong>{{ $descErr }}</strong></p>
			<p><em>Alarma generada el:</em> <strong> {{ $dt}} </strong></p>
		</div>

		<p>Alarma enviada en forma automática por SmartMonitor</p>
	</body>
</html>