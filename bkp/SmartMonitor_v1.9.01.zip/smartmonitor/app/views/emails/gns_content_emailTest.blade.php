<!DOCTYPE html>
<html lang="es-ES">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<p>El presente email verifica el correcto envio de email de Alarmas de SmartMonitor</p>
		<p><em>Envio generado el:</em> <strong> {{ $dt}} </strong></p>
		
	</body>
</html>