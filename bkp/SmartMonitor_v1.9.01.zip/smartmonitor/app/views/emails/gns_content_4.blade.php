<!DOCTYPE html>
<html lang="es-ES">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<p><h3>Smart Monitor: Se ha borrado el sensor: <strong>{{ $description }}</strong></h3></p>
		<h4>Detalles:</h4>
		<div>
			<p><em>ID:</em> <strong> {{ $sensor }} </strong></p>
			<p><em>Nombre::</em> <strong> {{ $description }} </strong></p>
			<p><em>Descripción:</em> <strong>El sensor y todos sus datos fueron borrados del sistema</strong></p>
			<p><em>Alarma generada el:</em> <strong> {{ $dt}} </strong></p>
		</div>

		<p>Alarma enviada en forma automática por <strong> SmartMonitor</strong> </p>
	</body>
</html>