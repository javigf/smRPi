$('#lstUsers').load('usuarios/getList');

$(document).on('show.bs.collapse','.collapse',function(){
	$('.collapse.in').collapse('hide');
});	


$(document).on('click','#usrBtnRole1',function(){
	$('#usrBtnRole1').addClass("btn-primary");
	$('#usrBtnRole2').removeClass("btn-primary");
});
$(document).on('click','#usrRole1',function(){
	$('#usrBtnRole1').addClass("btn-primary");
	$('#usrBtnRole2').removeClass("btn-primary");
});


$(document).on('click','#usrBtnRole2',function(){
	$('#usrBtnRole2').addClass("btn-primary");
	$('#usrBtnRole1').removeClass("btn-primary");
});
$(document).on('click','#usrRole2',function(){
	$('#usrBtnRole2').addClass("btn-primary");
	$('#usrBtnRole1').removeClass("btn-primary");
});


$(document).on('click','#btnListUsers',function(){
	$('#lstUsers').load('usuarios/getList', function(){
		$('#addEdUsers').removeClass("active");
		$('#lstUsers').addClass("active")
	});
	
	$(".classBtnUser").prop("disabled", true);
	
	var usrData = {
		message: 'Refrescando listado de usuarios!! ',
		color: '#739E73',
		icon: 'refresh'
	};
	box(usrData);
});


$(document).on('click','#btnNewUser',function(){
	$(".classBtnUser").prop("disabled", true);
	$('#addEdUsers').load('usuarios/getAdd', function(){
		$('#addEdUsers').addClass("active");
		$('#lstUsers').removeClass("active");
	});
});



$(document).on('click','#btnEditUser',function(){
	var id = $(this).data('id');
	var usrData = {
		message: 'Cargando usuario....',
		color: '#739E73',
		icon: 'refresh'
	};
	box(usrData);

	$(".classBtnUser").prop("disabled", true);

	$('#addEdUsers').load('usuarios/getUser/'+id, function(){
		$('#addEdUsers').addClass("active");
		$('#lstUsers').removeClass("active");
	});		  	
	
});


$(document).on('click','#usrSubmit',function(){
	var formUser = $('#'+this.form.id);

	$(".classBtnUser").prop("disabled", true);

	$.ajax({
		//type: formUser.attr('method'),
		type: 'POST', // Version 1.9.0
		url: formUser.attr('action'),
		data: formUser.serialize(),
		success: function (usrData) {
			box(usrData);
			if (usrData.action == 'add'){
				$(formUser)[0].reset();
			}
			$(".classBtnUser").prop("disabled", false);
		},
	});
	return false;
});


//***************************************
//INICIO Delete USER
//***************************************
$(document).on('click','.btn-delete',function(){
	var id = $(this).data('id');
	var row = $(this).parents('tr')
	var rowParent = $(this).closest('tr').prev()

	$(".classBtnUser").prop("disabled", true);

	$.ajax({
		type: 'POST',
		url: 'formUserDel',
		data: {id : id},
		success: function(usrData) {
			row.fadeOut(1000); 
			rowParent.fadeOut(1000);
			setTimeout(function () {
				$(".classBtnUser").prop("disabled", false);
			}, 1000);	
			return 0;
		},
		error: function(usrData){
			usrData.color = '#C46A69';
			usrData.icon = 'down';
			usrData.message = "Error al borrar el usuario";
			box(usrData);
			$(".classBtnUser").prop("disabled", false);
			return 1;
		}
	});
});
	
//***************************************
//FIN Delete USER
//***************************************	

$('.todo .checkbox > input[type="checkbox"]').click(function() {
	var $this = $(this).parent().parent().parent();
	var $thisbox = $(this).parent();
	var id = $(this).val(); 
	$.ajax({
		type: 'GET',
		url: 'alertsDispatcher/checkedAlert/'+id,
			error: function(xhr, status){
				var data = {
					message: 'Error al actualizar la Alarma: '+id,
					color: '#C46A69',
					icon: 'down'
				};
				$thisbox.remove();
				box(data);
			},
			success:function(data){
				$this.addClass("complete");
				$thisbox.remove();
				box(data);
		}
	});
})


function responseWidget(dataWidget)
	{
		$('#wgtForm').find('input, textarea, button, select, radio').prop("disabled", false);
		$('#wgtTitle').val(dataWidget.title).focus();
		$('#wgtActive').prop('checked',parseInt(dataWidget.active));
		$('#wgtSubTitle').val(dataWidget.subtitle);
		$('#wgtIcon_'+dataWidget.icon).prop('checked',true);
		$('#wgtMove').prop('checked',parseInt(dataWidget.move));
		$('#wgtCollapsible').prop('checked',parseInt(dataWidget.collapsible));
		$('#wgtClose').prop('checked',parseInt(dataWidget.close));

		$("#wgtSnsr").select2("val","");
		var val = $("#wgtSnsr").select2('val');
		var arrSensorsId = new Array();
		arrSensorsId = dataWidget.sensors_id.split(",")
		for (i = 0; i < arrSensorsId.length; i++){
			val.push([arrSensorsId[i]]);
		}
		$("#wgtSnsr").select2("val",val, true);

		$("#wgtSnsr").select2({
			placeholder: "Selecione los sensores a filtrar",
			formatNoMatches: function () { return "No se encontraron mas Sensores"; },
		
	});
	}

	var wgtForm = $('#wgtForm');
	wgtForm.bind("submit",function () {
		$.ajax({
			//type: wgtForm.attr('method'),
			type: 'POST', // Version 1.9.0
			url: wgtForm.attr('action'),
			data: wgtForm.serialize(),
			success: function (dataWidget) {
				box(dataWidget);
			},
		});

		return false;
	});

	function selectOptnWidget(id){
		var select = document.getElementById(id);
		var idWidget = select.value;
		
		if(idWidget == 0){
			document.getElementById("wgtForm").reset();
			$('#wgtForm').find('input, textarea, button, select, radio').prop("disabled", true);
			$('#wgtId').prop("disabled", false);
			
			return false;
		}

		$.ajax({
			type: 'GET',
			url: 'formWidget/selectOptn/'+idWidget,
			success: function(dataWidget){
			   responseWidget(dataWidget);
			   return 0;
			},
		})
		
		return false;
	}    	



if(document.getElementById("ssrRange") !== null)
{
	$('#ssrRange').html('{{ Form::text("val_sensor",null,array("id" => "val_sensor")) }}');
	$("#val_sensor").ionRangeSlider({
		min: 0,
		max: 100,
		from: 0,
		to: 100,
		type: 'double',
		disable: true,
	});
}

function response(data,sensor)
{
	$('#desc_sensor').prop("disabled", false);
	$('#ssrActive').prop("disabled", false); 
	$('#dropdownSensorActions').prop("disabled", false); // Version 1.9.0
	
	if(data.idStatus == 0){
		$('#ssrActive').prop('checked',true);
		$('#spanSsrActive').addClass('txt-color-normal'); // Version 1.9.0
		$('#spanSsrActive').removeClass('txt-color-purple txt-color-nuevoSensor'); // Version 1.9.0
	/*### Version 1.9.0 ###*/
	}else if(data.idStatus == 1) { 
		$('#ssrActive').prop('checked',false); 
		$('#spanSsrActive').addClass('txt-color-purple'); 
		$('#spanSsrActive').removeClass('txt-color-normal txt-color-nuevoSensor');
	}else{
		$('#ssrActive').prop('checked',false);
		$('#spanSsrActive').addClass('txt-color-nuevoSensor');
		$('#spanSsrActive').removeClass('txt-color-normal txt-color-purple');
	}
	/*##### #####*/
	

	$('#desc_sensor').val(data.ssrDesc);
	/*### Version 1.9.0 ###*/ 
		//Delete Sensor
	$('#contentDeleteSensor a').text(data.ssrDesc); 
	$('#linkDeleteSensor').prop('href','.' + sensor);
	$('#ssrCfgCollapse').addClass(sensor);
	$('#ssrCfgDecSensor').html( data.ssrDesc + ' (' + sensor + ')');
	$('#ssrCfgDeleteButton').attr('data-id' , sensor); 
	$('#ssrCfgDeleteButton').attr('disabled' , false); 
	/*##### #####*/


	if(data.max_range == 0){
		$('#ssrAdvise').removeClass('hide');
		$('#ssrRange').hide();
		$('#ssrRange').html('{{ Form::text("val_sensor","0;0",array("id" => "val_sensor")) }}');
	}
	else{	
		$('#ssrRange').show();
		$('#ssrAdvise').addClass('hide');
		$('#ssrRange').html('{{ Form::text("val_sensor",null,array("id" => "val_sensor")) }}');

		$("#val_sensor").ionRangeSlider({
			min: parseInt(data.min_range),
			max: parseInt(data.max_range),
			from: parseInt(data.min),
			to: parseInt(data.max),
			type: 'double',
			step: 1,
			postfix: data.unit,
			prettify: false,
			grid: true,
		});
	}
	$('#umbSubmit').prop("disabled", false);
}

function selectOptn(ssrId){


	var select = document.getElementById(ssrId);
	var sensor = select.value;

	$('#umbSubmit').prop("disabled", true);
	$('#ssrForm').find('input, textarea, button,checkbox').prop("disabled", true);
	$('#spanSsrActive').removeClass('txt-color-normal txt-color-purple txt-color-nuevoSensor'); // Version 1.9.0

	$('.collapse.in').collapse('hide');


	if(sensor == 0){
		document.getElementById("ssrForm").reset();
		$('#ssrAdvise').addClass('hide');
		$('#ssrRange').show();
		
		$('#ssrRange').html('{{ Form::text("val_sensor",null,array("id" => "val_sensor")) }}');	
		$("#val_sensor").ionRangeSlider({
			min: 0,
			max: 100,
			from: 0,
			to: 100,
			type: 'double',
		 	disable: true,
		});

		return false;
	}

	var selected = select.options[select.selectedIndex];
	var grp = selected.parentNode.label;

	document.getElementById('name_sensor').value = sensor;
	document.getElementById('grp_sensor').value = grp;

	$.ajax({
		type: 'GET',
		url: 'form/selectOptn/'+sensor,
		success: function(data){
		   response(data,sensor);
		   return 0;
		},
	})

	return false;
}


//***************************************
//Update current value of select box
//***************************************
function getStatusSensor()
{
	var nameSensor = $('#name_sensor').val();

	if (nameSensor != "Sensor")
	{
		$('#ssrId').prop("disabled", true);

	 	$.ajax({
			type: 'GET',
			url: 'form/getSelectOptn/'+nameSensor,
			success: function(data){
			   ssrResponseListSensors(data,nameSensor);
			   return 0;
			},
		})
		return false;	
	}
}

function ssrResponseListSensors(data,nameSensor)
{
	$('#ssrId option').each(function () {
  		if (null != data && this.value == nameSensor){
			$('#ssrId').prop("disabled", false);
    		this.text = data;
			$("#ssrId").val(nameSensor).trigger("change");
			return 0;
		}
	});
}
//***************************************
// FIN
//***************************************


var ssrForm = $('#ssrForm');
ssrForm.bind("submit",function () {
	$.ajax({
		//type: ssrForm.attr('method'),
		type: 'POST', // Version 1.9.0
		url: ssrForm.attr('action'),
		data: ssrForm.serialize(),
		success: function (data) {
			box(data);
			getStatusSensor();
		},
	});
	return false;
});


function box(data){
	var d = new Date();
	var hour = d.getHours()+":"+d.getMinutes()+":"+d.getSeconds(); 
	$.smallBox({
		title : data.message,
		content : "<i class='fa fa-clock-o'></i> <i>"+hour+"</i>",
		color : data.color,
		iconSmall : "bounce animated fa fa-thumbs-"+data.icon,
		timeout : 6000
	});
}


//***************************************
//INICIO Set Email // Version 1.9.0
//***************************************


$('#userPassword').change(function(){
	if($("#userPassword").is(':checked')) {
		$('#emailPassword').prop("disabled", true);
	}else{
		$('#emailPassword').prop("disabled", false);
	}
});

var emailForm = $('#emailForm');

$(document).on('click','#submitTest',function(){
	$('#submitAction').val('emailTest');	
	callEmailAjax();

	return false;
});

emailForm.bind("submit",function () {
	$('#submitAction').val('emailSubmit');
	callEmailAjax();

	return false;
});


function callEmailAjax()
{
	$.ajax({
		//type: emailForm.attr('method'),
		type: 'POST', // Version 1.9.0
		url: emailForm.attr('action'),
		data: emailForm.serialize(),
		success: function (data) {
			box(data);
		},
		
		error: function(result){
			result.color = '#C46A69';
			result.icon = 'down';
			result.message = "Error ERR:AJA478";
			box(result);
			$('#ssrCfgDeleteButton').attr('disabled' , false); 
		}

	});
	return false;
}



//***************************************
//FIN Set Email // Version 1.9.0
//***************************************



if (typeof(itemsGetTotal) != "undefined" && itemsGetTotal > 0){
	$('#ftrTblMessage').text(formatItemsGetTotal +' Registros encontrados');	

	if(itemsGetTotal < 20001){
		$('#ftrTblExpPdf').removeClass('disabled btn-info');
		$('#ftrTblExpPdf').addClass('btn-danger');
		$('#ftrTblExpExcel').removeClass('disabled btn-info');
		$('#ftrTblExpExcel').addClass('btn-success');
		$('#ftrTblExpExcel').popover('destroy')
	}else{
		$('#ftrTblExpPdf').addClass('disabled btn-info');
		$('#ftrTblExpPdf').removeClass('btn-danger');
		$('#ftrTblExpExcel').addClass('disabled btn-info');
		$('#ftrTblExpExcel').removeClass('btn-success');
		$('#ftrTblExpExcel').popover('show');
	}
}else{
	$('#ftrTblMessage').text('Ningun registro encontrado');	
}



//***************************************
//INICIO Delete SENSOR // Version 1.9.0
//***************************************

$(document).on('click','#ssrCfgDeleteButton',function(){
	var idSensor = $(this).attr("data-id"); 
	var descSensor = $('#desc_sensor').val();
	$('#ssrCfgDeleteButton').attr('disabled' , true); 
	$.ajax({
		type: 'POST',
		url: 'formSensorDel',
		data: {descSensor : descSensor, idSensor : idSensor },		
		success: function(result) {
			box(result);
			//$('#ssrId option:selected').attr('disabled','disabled');
			$('#ssrId option:selected').remove();
			$("#ssrId").val(0).trigger("change");
			
		},

		error: function(result){
			result.color = '#C46A69';
			result.icon = 'down';
			result.message = "Error al borrar el Sensor ERR:AJA540";
			box(result);
			$('#ssrCfgDeleteButton').attr('disabled' , false); 
		}

	});
	return false
	

});

//***************************************
//FIN Delete SENSOR // Version 1.9.0
//***************************************
