<table class="table table-striped table-bordered table-hover">
	<div class="row">
		<div class="col-lg-6">
			<h3 class="text-info"><strong>Listado se usuarios</strong></h3>
		</div>
		<div class="col-lg-6">
			<br>
			{{Form::button('<strong>Crear usuario</strong>',array('id' => 'btnNewUser','class' => 'btn btn-success pull-right classBtnUser'))}}
		</div>
	</div>
	
	<thead>
		<tr>
			<th>{{strtoupper('Nombre Completo')}}</th>
			<th>{{strtoupper('Id de Usuario')}}</th>
			<th>{{strtoupper('correo electronico')}}</th>
			<th>{{strtoupper('Acciones')}}</th>
		</tr>
	</thead>
	<tbody>
		@foreach ($results as $values)
			<tr>
				<td>{{$values['first_name']}} {{$values['last_name']}}</td>
				<td>{{$values['username']}}</td>
				<td>{{$values['email']}}</td>
				<td>
					<div class="dropdown">
						{{Form::button('<strong>Acciones</strong> <span class="caret"></span>',array('class' => 'btn dropdown-toggle btn-primary btn-xs btn-group-justified classBtnUser', 'data-toggle' => 'dropdown', 'id' => 'dropdownMenu1', 'aria-expanded' => 'true'))}}

					  	</button>
					  	<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
					    	<li role="presentation"><a role="menuitem" tabindex="-1" id="btnEditUser" data-id="{{$values['id']}}">Editar</a></li>
					    	<li role="presentation"><a role="menuitem" tabindex="-1" data-toggle="collapse" href=".id1{{$values['id']}}" id="btnChgPwd" data-id="{{$values['id']}}" aria-expanded="false" aria-controls="collapseExample">Cambiar clave</a></li>
					    	<li role="presentation" class="divider"></li>
					    	<li role="presentation"><a role="menuitem" tabindex="-1" data-toggle="collapse" href=".id{{$values['id']}}" aria-expanded="false" aria-controls="collapseExample" >Borrar</a></li>
					    </ul>
					</div>
				</td>
			</tr>
			<tr>
				<td colspan="4" class="hiddenRow">
					<div class="collapse id{{$values['id']}}" >
			    		<div class="well">
				    		<h4 class="text-danger">
				    			{{Form::button('<strong>Borrar usuario</strong>',array('class' => 'btn btn-danger btn-delete classBtnUser', 'data-id' => $values['id']))}}
				    		<strong> {{$values['first_name']}} {{$values['last_name']}} ({{$values['username']}})</strong></h4>
			    		</div>
				    </div>
				</td>
			</tr>
			<tr>
				<td colspan="4" class="hiddenRow">
					<div class="collapse id1{{$values['id']}}" >
			    		<div class="well">
			    			{{ Form::open(array('url' => 'formUser','id' => 'formUser_'.$values['id'], 'novalidate' => 'novalidate', 'class' => 'register_ajax')) }}
			    				<div class="row">
									<div class="col-sm-4">
										{{ Form::password('userPassword1',array('id' => 'userPassword1', 'class' => 'form-control input-sm','placeholder' => 'Clave')) }}
									</div>
									<div class="col-sm-4">
										{{ Form::password('userPassword2',array('id' => 'userPassword2', 'class' => 'form-control input-sm','placeholder' => 'Repetir clave')) }}
									</div>
									<div class="col-sm-4">
										{{ HTML::decode(Form::button('<i class="fa fa-save"></i> <strong>Confirmar</strong>',array('id' => 'usrSubmit','class' => 'btn btn-success pull-right classBtnUser btn-sm','type' => 'botton'))) }}
									</div>
									{{Form::hidden('usrPwd',$values['id']);}}
									{{Form::hidden('userName',$values['username']);}}
								{{ Form::close() }}	
			    		</div>
				    </div>
				</td>
			</tr>
		@endforeach
	</tbody>
</table>

