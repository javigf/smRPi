{{ Form::open(array('url' => 'formUser','id' => 'formUser', 'novalidate' => 'novalidate', 'class' => 'register_ajax')) }}

<h3 class="text-info"><strong>
	@if(is_null($results['id']))
		Agregar nuevo usuario
	@else
		Editar usuario
	@endif
</strong></h3>
	<div class="row">
		<div class="col-sm-6">
			<div class="form-group">
				<div class="input-group">
					<span class="input-group-addon"><i class="fa fa-user fa-lg fa-fw"></i></span>
					{{ Form::text('userFirstName',$results['first_name'],array('id' => 'userFirstName', 'class' => 'form-control input-lg', 'placeholder' => 'Nombre del usuario' )) }}
				</div>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<div class="input-group">
					<span class="input-group-addon"><i class="fa fa-user fa-lg fa-fw"></i></span>
					{{ Form::text('userLastName',$results['last_name'],array('id' => 'userLastName', 'class' => 'form-control input-lg', 'placeholder' => 'Apellido del usuario' )) }}
				</div>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-sm-5">
			<div class="form-group">
				<div class="input-group">
					<span class="input-group-addon"><i class="fa fa-user fa-lg fa-fw"></i></span>
					{{ Form::text('userName',$results['username'],array('id' => 'userName', 'class' => 'form-control input-lg', 'placeholder' => 'Id usuario' )) }}
				</div>
			</div>
		</div>

		<div class="col-sm-offset-1 col-sm-6">
			<label class="">
				{{ Form::Radio('usrRole',1, ($results['role_id'] == 1) ? true : false, array('id' => 'usrRole1','class' => 'radiobox')) }}
					<span>&nbsp;{{Form::button('Operador',array('class'=> 'btn', 'id' => 'usrBtnRole1'))}}</span>  
			</label>						  					
			<label class="">
				{{ Form::Radio('usrRole',2, ($results['role_id'] == 2) ? true : false, array('id' => 'usrRole2','class' => 'radiobox')) }}
					<span>&nbsp;{{Form::button('Administrador',array('class'=> 'btn', 'id' => 'usrBtnRole2'))}}</span>  
			</label>
		</div>

	</div>

	<div class="row">
		<div class="col-sm-8">
			<div class="form-group">
				<div class="input-group">
					<span class="input-group-addon"><i class="fa fa-envelope fa-lg fa-fw"></i></span>
					{{ Form::text('userEmail',$results['email'],array('id' => 'userEmail', 'class' => 'form-control input-lg','placeholder' => 'Direccion de correo electronico')) }}
				</div>
			</div>
		</div>
	</div>

	@if(is_null($results['id']))
		<div class="row">
			<div class="col-sm-6">
				<div class="form-group">
					<div class="input-group">
						<span class="input-group-addon"><i class="fa fa-lock fa-lg fa-fw"></i></span>
						{{ Form::password('userPassword1',array('id' => 'userPassword1', 'class' => 'form-control input-lg','placeholder' => 'Clave')) }}
					</div>
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<div class="input-group">
						<span class="input-group-addon"><i class="fa fa-lock fa-lg fa-fw"></i></span>
						{{ Form::password('userPassword2',array('id' => 'userPassword2', 'class' => 'form-control input-lg','placeholder' => 'Repetir clave')) }}
					</div>
				</div>
			</div>
		</div>
	@else
		{{Form::hidden('usrId',$results['id']);}}
	@endif

	<div class="row">
		<div class="col-md-12">
			<div class="form-actions">
				{{ HTML::decode(Form::button('<i class="fa fa-list"></i> <strong>Listar usuarios</strong>',
					array('id' => 'btnListUsers','class' => 'btn btn-warning classBtnUser','type' => 'button'))) }}
				{{ HTML::decode(Form::button('<i class="fa fa-save"></i> <strong>Confirmar</strong>',
					array('id' => 'usrSubmit','class' => 'btn btn-success classBtnUser','type' => 'botton'))) }}
			</div>

			<div class="col-md-12"><br></div>
		</div>
	</div>
{{ Form::close() }}	


<script type="text/javascript">
	
	$(document).ready(function() {
   		pageSetUp();
	});

</script>
