@if ($items->getTotal() > 0)
	<?php 
		$_value = 'OTHER'; 
		$id_group = $_value; 
	?>

	<table class="table table-striped table-bordered table-hover">
		<thead>
			<tr>
			@foreach ($items[0]['original'] as $key => $values)
				@if($key != $condition)
					@if($key != 'id_group')
						<th>{{strtoupper($key)}}</th>	
					@endif
				@endif
			@endforeach
			</tr>
	  	</thead>
	  	<tbody>
	  	@foreach ($items as $values)
			@if($values['original'][$condition] == $status)
				<tr class="danger">
			@else
				<tr>
			@endif
				@foreach ($values['original'] as $key => $value)
					@if($key != $condition)
						@if($key == 'id_group')
							<?php $id_group = ($value == 'PT') ? $value : $_value ?>
						@else
							<td>
								@if ($id_group == 'PT')
									{{($value == -10) ? 'Abierta' : 'Cerrada'}}
									<?php $id_group = $_value ?>
								@else
									{{$value}}
								@endif
							</td>	

						@endif
					@endif
				@endforeach
				</tr>
		@endforeach
		</tbody>
	</table>
	<?php echo $items->appends(Input::except('page'))->links(); ?>
@else
	<div class="alert alert-warning" role="alert">
		<h2><strong> La consulta no arrojo resultados</strong></h2>
	</div>
@endif      

<script type="text/javascript">
	var itemsGetTotal = {{$items->getTotal()}}
	var formatItemsGetTotal = '{{number_format($items->getTotal())}}'
	@include('dashboard.library.gns_content')
</script>
