<?php print_r($results) ?>

<h1>ERROR</h1>