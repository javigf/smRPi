@if (count($results)>0)
	<div class="padding-10">
		<figure style="height: 265px;" id="graph-{{ $contentDiv }}"></figure>
	</div>
	<style>
		@foreach ($results->id as $key => $value)
			@if ($value->id_error == 5)
				#{{$key}} {fill: #DD0009;}
			@elseif ($value->id_error >= 10 and $value->id_error < 60)
				#{{$key}} {fill: #848484;}
			@elseif ($value->id_error == 60)
				#{{$key}} {fill: #D6CB04;}
			@else
				#{{$key}} {fill: #0E8825;}
			@endif
		@endforeach
	</style>

	{{ HTML::script('js/plugin/xcharts.js'); }}

	<script>

	 var tt = document.createElement('div'),
		leftOffset = -(~~$('html').css('padding-left').replace('px', '') + ~~$('body').css('margin-left').replace('px', '')),
	  	topOffset = -32;
		tt.className = 'ex-tooltip';
		document.body.appendChild(tt);

	var yScale = "exponential";

	var data{{ $contentDiv }} = {
		  "main": [
			{
			  "className": ".sensors",
			  "label": "sensores",
			  "data": [
				@foreach ($results->id as $key => $value) 
					{
						"x": '{{$key}}',
						"y": {{$value->val}},
						"label": '{{$value->description}}',
						"status" : '{{$value->descError}}',
						"idError": '{{$value->id_error}}',
						"unit": ' {{$value->unit}}',
					},
				@endforeach

			  ],
			}
		  ],
		  "xScale": "ordinal",
		  "yScale": yScale,
		  "comp": [
			{
			  "className": ".srs_max",
			  "label": "max",
			  "data": [@foreach ($results->id as $key => $value) 
					{
					  	"x": '{{$key}}',
					  	"y": {{$value->max}},
						"label": 'Rango maximo definido ',
					   	"unit": ' {{$value->unit}}',
					   	"idError":  -1,

					},
				@endforeach
			  ],
			  "type": "line-dotted"
			},
			{
			  "className": ".srs_min",
			  "label": "min",
			  "data": [@foreach ($results->id as $key => $value) 
					{
					  	"x": '{{$key}}',
					  	"y": {{$value->min}},
					   	"label": 'Rango minimo definido ',
					   	"unit": ' {{$value->unit}}',
					   	"idError": -1,
					   
					},
				@endforeach
			  ],
			  "type": "line-dotted"
			} 
					]
		};

		var opts{{ $contentDiv }} = {
	  		tickFormatX: function (x) { return x; },
	  		paddingLeft: 30,
	  		paddingRight: 20,
	  		"mouseover": function (d, i) {
	    		var pos = $(this).offset();
	    		$(tt).hide();
	    		
	      		if(d.idError <= 0){
    				var textd = d.label + ': <strong>' + d.y + d.unit+'</strong>';
      			}else if(d.idError == 5){
    				var textd = d.label +'<br>Estado: <strong>'+ d.status+'</strong>' + '<br>Valor: <strong>' + d.y + d.unit+'</strong>';
      			}else{
      			var textd = d.label +'<br>Estado: <strong>'+ d.status+'</strong>';
      			}
      			$(tt).html(textd).css({top: topOffset + pos.top, left: pos.left + leftOffset}).show();
  				},

			 "mouseout": function (x) {
	    		$(tt).hide();
	  		}
		};
		
		chart{{ $contentDiv }} = new xChart('bar', data{{ $contentDiv }}, '#graph-{{ $contentDiv }}',opts{{ $contentDiv }});

		$( window ).resize(function() {
				chart{{ $contentDiv }} = new xChart('bar', data{{ $contentDiv }}, '#graph-{{ $contentDiv }}',opts{{ $contentDiv }});
		});

	</script>

@else
	<div class="alert alert-info" role="alert">
		<h2><strong> Los sensores activos no han registrado datos</strong></h2>
	</div>
@endif