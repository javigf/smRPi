<div class="table-filters">
	<div class="col-lg-8">
		<h2><strong>Opciones de Filtrado</strong></h2>
	</div>
	<div class="col-lg-4 padding-top-10">	
		<div class="pull-right">
				<a class="btn btn-primary btn-info btn-sm disabled" href="exportar/excel" target="_blank" id="ftrTblExpExcel"role="button" data-toggle="popover" data-content="Consulta muy extensa. Se exportaran busquedas menores a 20.000 registros" data-placement='left'><i class="fa fa-file-excel-o"></i> Exportar Excel</a>  <a class="btn btn-primary btn-info btn-sm disabled" href="exportar/pdf" target="_blank" title="Exportar a Pdf" id="ftrTblExpPdf">
		        	<i class="fa fa-file-pdf-o"></i> Exportar Pdf
		        </a>
		</div>	
	</div>
	
	
	{{ Form::open(array('url' => 'ftrTblForm','id' => 'ftrTblForm', 'novalidate' => 'novalidate', 'class' => 'register_ajax')) }}       
	
		<div class="bs-callout bs-callout-{{ $results['colorBootstrap'] }}">		
						
			<div class="row">
				<div class="col-sm-4 ">
					<h4><strong>Selección de Sensores a filtrar</strong></h4><br>
					<div class="form-group">
						@if (array_key_exists('sensors',$results[0]) == true)
							{{ Form::select('ftrTblSensor[]', $results[0]['sensors'], null,array('multiple' => true, 'id' => 'ftrTblSensor', 'style' => 'width:100%', 'class' => 'tabl, select2')) }}
						@else 
							<div class="text-center alert alert-{{ $results['colorBootstrap'] }}" role="alert">
								<h3><strong>No se encuetran sensores conectados</strong></h3>
							</div>
						@endif					
					</div>
				</div>
			
				<div class="col-sm-4">
					<h4><strong>Selección de rango de valores a filtrar</strong></h4>	
					<div id='divFtrTblValues'>{{ Form::text("ftrTblValues",null, array('id' => 'ftrTblValues')) }}</div>
					
					<div id="divFtrTblAdvise" class="alert alert-info hide" role="alert">
                        <h6>El sensor no admite valores maximos y minimos</h6>
                    </div>
    			</div>
				
				@if($results[1] == 'HSTRYD')
					<div class="col-sm-4 ">
					<h4><strong> Selección del rango horario a filtrar</strong></h4><br>
						<div class="col-sm-5">	
							<div class="input-group ftrTblFromHr" data-placement="left" data-align="top" data-autoclose="true">
								{{ Form::text("ftrTblFromHr",null, array('id' => 'ftrTblFromHr', 'class' => 'form-control', 'placeholder' => 'Desde')) }}
								<span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
							</div>
						</div>
						<div class="col-sm-5">	
							<div class="input-group ftrTblToHr" data-placement="left" data-align="top" data-autoclose="true">
						    	{{ Form::text("ftrTblToHr",null, array('id' => 'ftrTblToHr', 'class' => 'form-control', 'placeholder' => 'Hasta')) }}
								<span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
							</div>
						</div>
					</div>
				@else
	    			<div class="col-sm-4 ">
		    			<h4><strong> Selección del rango de fechas a filtrar</strong></h4><br>
						<div class="col-sm-6">
							<div class="input-group">
								{{ Form::text("ftrTblFrom",null, array('id' => 'ftrTblFrom', 'class' => 'form-control', 'placeholder' => 'Desde')) }}
								<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
							</div>
						</div>
					
						<div class="col-sm-6">
							<div class="input-group">
								{{ Form::text("ftrTblTo",null, array('id' => 'ftrTblTo', 'class' => 'form-control', 'placeholder' => 'Hasta')) }}
								<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
							</div>
						</div>	
					</div>				
				@endif

			</div>

			<div class="row">
				<div class="col-md-12">
					<div class="col-md-6">
						<h4><strong><div id="ftrTblMessage"></div></strong></h2>
					</div>
					<div class="col-md-6 pull-right">
							{{ HTML::decode(Form::button('<i class="fa fa-search"></i> <strong>Buscar</strong>',
								array('name' => 'ftrTblSubmit','id' => 'ftrTblSearch','class' => 'btn btn-primary pull-right','type' => 'submit' ))) }}	
					</div>
				</div>
			</div>
		
		{{ Form::close() }}

	
	</div>

{{ HTML::script('js/plugin/select2.min.js'); }}
{{ HTML::script('js/plugin/ion.rangeSlider.min.js'); }}
{{ HTML::script('js/plugin/clockpicker.min.js'); }}

<script type="text/javascript">
var arr=[];
var rslt1='{{$results[1]}}';


@foreach($results[0]['max_value']as $key=>$element)
	arr.push({{$element}});
	var startMax=Math.max.apply(Math,arr);
@endforeach 


//Add version 1.8.2  Valores negativos minimos 
@foreach($results[0]['min_value']as $key=>$element)
	arr.push({{$element}});
	var startMin=Math.min.apply(Math,arr);
@endforeach 



$('#ftrTblSensor').click(function(){
	var s2=$('#ftrTblSensor').val();

	if(s2){
		var arr=[];
		@foreach($results[0]['max_value']as $key=>$element)
			if(String(s2).indexOf('{{$key}}')>-1){
				arr.push({{$element}});
				var max = Math.max.apply(Math,arr)
			}
		@endforeach


		@foreach($results[0]['min_value']as $key=>$element)
			if(String(s2).indexOf('{{$key}}')>-1){
				arr.push({{$element}});
				var min = Math.min.apply(Math,arr)
			}
		@endforeach

	}else{
		var max = startMax
		var min = startMin //version 1.8.2
	}

	if(max == 0){
		$("#divFtrTblAdvise").removeClass('hide')
		$("#divFtrTblValues").hide();
	}else{
		$("#divFtrTblValues").show();
		$("#divFtrTblAdvise").addClass('hide')
	}

	slider.update({
		max:max,
		to:max,
		min:min, //Version 1.8.2
		from:min, //Version 1.8.2
	})

});

$('.ftrTblFromHr').clockpicker({
    autoclose: true,
    afterDone: function() {
        FromTo('ftrTblFromHr', 'ftrTblToHr')
    }
});
$('.ftrTblToHr').clockpicker({
    autoclose: true,
    afterDone: function() {
        FromTo('ftrTblToHr', 'ftrTblFromHr')
    }
});

function FromTo(id1, id2) {
    var ftrTblFromHr = $('#ftrTblFromHr').val();
    var ftrTblToHr = $('#ftrTblToHr').val();
    var id = $('#' + id1).val();
    if (ftrTblToHr < ftrTblFromHr) {
        $('#' + id2).val(id)
    }
}
$(".select2").select2({
    placeholder: "Selecione los sensores a filtrar",
    formatNoMatches: function() {
        return "No se encontraron mas Sensores"
    },
});

$(function() {
    $("#ftrTblValues").ionRangeSlider({
        hide_min_max: true,
        keyboard: true,
        min: startMin, //Version 1.8.2
        max: startMax,
        from: startMin, //Version 1.8.2
        to: startMax,
        type: 'double',
        step: 1,
        grid: true
    })
});

var slider = $("#ftrTblValues").data("ionRangeSlider");
if (rslt1 == 'HSTRY') {
    var maxDate = '-1'
} else {
    var maxDate = '0'
}

$("#ftrTblFrom").datepicker({
    defaultDate: "+1w",
    changeMonth: true,
    numberOfMonths: 1,
    dateFormat: 'yy/mm/dd',
    prevText: '<i class="fa fa-chevron-left"></i>',
    nextText: '<i class="fa fa-chevron-right"></i>',
    maxDate: maxDate,
    onClose: function(selectedDate) {
        $("#ftrTblTo").datepicker("option", "minDate", selectedDate)
    }
});
$("#ftrTblTo").datepicker({
    defaultDate: "+1w",
    changeMonth: true,
    numberOfMonths: 1,
    dateFormat: 'yy/mm/dd',
    prevText: '<i class="fa fa-chevron-left"></i>',
    nextText: '<i class="fa fa-chevron-right"></i>',
    maxDate: maxDate,
});
var ftrTblForm = $('#ftrTblForm');
ftrTblForm.bind("submit", function() {
    $.ajax({
        type: ftrTblForm.attr('method'),
        url: ftrTblForm.attr('action'),
        data: ftrTblForm.serialize(),
        success: function(dataWidget) {
            wgtBox(dataWidget);
            $('#qtable').load('busqueda/' + rslt1 + '?page=1')
        },
    });

    function wgtBox(dataWidget) {
        var d = new Date();
        var hour = d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
        $.smallBox({
            title: dataWidget.message,
            content: "<i class='fa fa-clock-o'></i> <i>" + hour + "</i>",
            color: dataWidget.color,
            iconSmall: "bounce animated fa-2x fa fa-" + dataWidget.icon,
            timeout: 6000
        })
    }
    return false
});
</script>
