<div id="nodes" class="fill" ></div>

<script type="text/javascript">

var data = {{ $results }};

var dataMap = data.reduce(function(map, node) {
	 map[node.name] = node;
 	return map;
}, {});


var treeData = [];
	data.forEach(function(node) {
	var parent = dataMap[node.parent];
 	if (parent) {
  		(parent.children || (parent.children = []))
   		.push(node);
 	} else {
  	treeData.push(node);
 	}
});

function color(d) {

	if (d.idError == 0) {
		var childNode = "#0E8825";
	}else if (d.idError == 5){
		var childNode = "#FF000A";
	}else if (d.idError >= 10 && d.idError < 60){
		var childNode = "#848484";
	}else if (d.idError == 60){
		var childNode = "#D6CB04";
	};

	if (d.idStatus == 1) {
		var childNode = "#9700A9";
	}else if (d.idStatus == 2){
		var childNode = "#ffffff";
	};

  	return d._children ? "#388f49" : d.children ? "#c6dbef" : childNode;
}

function collapse(d) {
  if (d.children) {
    d._children = d.children;
    d._children.forEach(collapse);
    d.children = null;
  }
}


var margin = {top: 20, right: 120, bottom: 20, left: 120},
  	width = $(document).width(); - margin.right - margin.left,
  	height = $(document).height(); - margin.top - margin.bottom;

var i = 0,
  	duration = 750,
  	root;

var tree = d3.layout.tree()
  	.size([height, width]);

var diagonal = d3.svg.diagonal()
  	.projection(function(d) { return [d.y, d.x]; });

var svg = d3.select("#nodes").append("svg")
  	.attr("width", width + margin.right + margin.left)
  	.attr("height", height + margin.top + margin.bottom)
  	.append("g")
  	.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

var div = d3.select("#nodes").append("div")
   	.attr("class", "tooltip nodetooltip")

   	.style("opacity", 0);

root = treeData[0];
root.x0 = height / 2;
root.y0 = 0;
  
update(root);  

function update(source) {

	var levelWidth = [1];
    var childCount = function(level, n) {

        if (n.children && n.children.length > 0) {
            if (levelWidth.length <= level + 1) levelWidth.push(0);

            levelWidth[level + 1] += n.children.length;
            n.children.forEach(function(d) {
                childCount(level + 1, d);
            });
        }
    };
    childCount(0, root);
    var newHeight = d3.max(levelWidth) * 40;
    tree = tree.size([newHeight, width]);

	var nodes = tree.nodes(root).reverse(),
		links = tree.links(nodes);

  	nodes.forEach(function(d) { d.y = d.depth * 180; });


  	var node = svg.selectAll("g.node")
		.data(nodes, function(d) { return d.id || (d.id = ++i); });

  	var nodeEnter = node.enter().append("g")
		.attr("class", "node")
		.attr("transform", function(d) { return "translate(" + source.y0 + "," + source.x0 + ")"; })
		//.on("click", click)
		.on("mouseover",mouseOver)
		.on("mouseout",mouseOut)
		
	nodeEnter.append("circle")
		.attr("r", 1e-6)
	  	.style("fill", color)
	  	

	nodeEnter.append("text")
		.attr("x", function(d) { return d.children || d._children ? -15 : 15; })
		.attr("dy", ".35em")
		.attr("text-anchor", function(d) { return d.children || d._children ? "end" : "start"; })
		
		.text(function(d) { return d.alias; })
		.style("fill-opacity", 1e-6);
  
  	var nodeUpdate = node.transition()
		.duration(duration)
		.attr("transform", function(d) { return "translate(" + d.y + "," + d.x + ")"; });
  	

  		nodeUpdate.select("circle")
		.attr("r", 8)
  		.style("fill", color); 

  	nodeUpdate.select("text")
		.style("fill-opacity", 1);

  	var nodeExit = node.exit().transition()
		.duration(duration)
		.attr("transform", function(d) { return "translate(" + source.y + "," + source.x + ")"; })
		.remove();

  	nodeExit.select("circle")
		.attr("r", 1e-6);

  	nodeExit.select("text")
		.style("fill-opacity", 1e-6);

  	var link = svg.selectAll("path.link")
		.data(links, function(d) { return d.target.id; });

  	link.enter().insert("path", "g")
		.attr("class", "link")
		.attr("d", function(d) {
			var o = {x: source.x0, y: source.y0};
			return diagonal({source: o, target: o});
		});

  	link.transition()
		.duration(duration)
		.attr("d", diagonal);

  	link.exit().transition()
	.duration(duration)
	.attr("d", function(d) {
		var o = {x: source.x, y: source.y};
		return diagonal({source: o, target: o});
	})
	.remove();

  	nodes.forEach(function(d) {
  		d.x0 = d.x;
  		d.y0 = d.y;
  	})

}

function mouseOver(d) {

	var txtSpan = "<span style='color: #000000'>"
	

	if (d.idStatus == 0){
		if(d.idError < 10 ) {
			var register = d.register + " " + d.unit
		}else{
			var register = '----'
		}
	}else{
			d.error = d.statusDescription;
			var register = '----';
	}

	if (typeof d.sensor != 'undefined'){
	    div.transition()
	    .duration(200)
	    .style("opacity", .9);
	    div.html(
	        "Nombre: <strong>" + d.sensor + "</strong><br/>" 
	       	+ "Valor: &nbsp;&nbsp;&nbsp;&nbsp;<strong>" + txtSpan + register + "</strong><br/></span>" 
	        + "Estado: &nbsp;&nbsp;" +  "<strong><i>"+ txtSpan + d.error + "</i></strong><br/></span>"
	    )
	    .style("left", (d3.event.pageX) -200 + "px")
	    .style("top", (d3.event.pageY - 200) + "px");
	}
}

function mouseOut() {
    div.transition()
        .duration(500)
         .style("opacity", 0);
};


var zb = d3.behavior.zoom().scaleExtent([0.5, 1]).on("zoom", function () { zoom(); });
zb.translate([margin.left, margin.top]);

d3.select("svg").call(zb);

	update(root);

function zoom() {
	var scale = d3.event.scale,
		translation = d3.event.translate,
		tbound = -height * scale * 100,
		bbound = height * scale,
		lbound = (-width + margin.right) * scale,
		rbound = (width - margin.bottom) * scale;

		translation = [
		Math.max(Math.min(translation[0], rbound), lbound),
		Math.max(Math.min(translation[1], bbound), tbound)];
		svg.attr("transform", "translate(" + translation + ")" + " scale(" + scale + ")");
} 

</script>
