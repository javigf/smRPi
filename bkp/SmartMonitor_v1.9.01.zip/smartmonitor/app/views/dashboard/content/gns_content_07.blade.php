<div class="col-sm-12">
	{{ Form::open(array('url' => 'configEmail','id' => 'emailForm', 'novalidate' => 'novalidate', 'class' => 'register_ajax')) }}		
		<div class="row">
			<div class="col-sm-12">
				<div class="form-bootstrapWizard">
					<br>
					 <ul class="bootstrapWizard form-wizard">
						<li class="active" data-target="#emailTab1">
							<a href="#emailTab1" data-toggle="tab"> <span class="step">1</span> <span class="title">Cuentas</span> </a>
						</li>
						<li data-target="emailtTab2">
						   <a href="#emailTab2" data-toggle="tab"> <span class="step">2</span> <span class="title">Servidor</span> </a>
						</li>
					</ul>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		<div class="tab-content">
			<div class="tab-pane active" id="emailTab1">
				<br>
				<h3><strong>Cuenta saliente </strong> - Direccion de envio</h3>
				<div class="row">
					<div class="col-sm-12">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-envelope fa-lg fa-fw"></i></span>
								{{ Form::text('emailFrom',$results['from'],array('id' => 'emailFrom', 'class' => 'form-control input-lg', 'placeholder' => 'Dirección correo saliente' )) }}
							</div>
						</div>
					</div>

					<div class="col-sm-12">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user fa-lg fa-fw"></i></span>
								{{ Form::text('emailName',$results['name'],array('id' => 'emailName', 'class' => 'form-control input-lg', 'placeholder' => 'Nombre del correo saliente' )) }}
							</div>
						</div>
					</div>
				</div>

				<br>
				<h3><strong>Cuentas destino </strong><em> - Separar las cuentas de email con comas (,)</em></h3>
				<div class="row">
					<div class="col-sm-12">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-file-o fa-lg fa-fw"></i></span>
								{{ Form::textarea('emailTo',$results['to'],array('id' => 'emailTo', 'class' => 'form-control input-lg', 'rows' => '2', 'placeholder' => 'Direccion correos de destinatarios' )) }}
							</div>
						</div>
					</div>
					<div class="col-sm-12">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-files-o fa-lg fa-fw"></i></span>
								{{ Form::text('emailCc',$results['cc'],array('id' => 'emailCc', 'class' => 'form-control input-lg', 'placeholder' => 'Direccion correos de destinatarios en copia' )) }}
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="tab-pane" id="emailTab2">
				<br>
				<h3><strong>Servidor </strong> - Configuracion SMTP</h3>
				<div class="row">
					<div class="col-sm-8">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-globe fa-lg fa-fw"></i></span>
								{{ Form::text('emailHost',$results['host'],array('id' => 'emailHost', 'class' => 'form-control input-lg', 'placeholder' => 'Nombre servidor SMTP' )) }}
							</div>
						</div>
					</div>

					<div class="col-sm-4">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-paragraph fa-lg fa-fw"></i></span>
								{{ Form::text('emailPort',$results['port'],array('id' => 'emailPort', 'class' => 'form-control input-lg', 'placeholder' => 'Puerto' )) }}
							</div>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-6">
						<label><strong>Seguridad</strong></label>
						<div class="form-group">
							<label class="">
								{{ Form::Radio('emailSecurity','ssl', $results['security']=='ssl', array('id' => 'emailSecurity_SSL','class' => 'radiobox')) }}
								<span>SSL</span> 
							</label>
							<label class="">
								{{ Form::Radio('emailSecurity','tls', $results['security']=='tls', array('id' => 'emailSecurity_TLS','class' => 'radiobox')) }}
								<span>TLS</span>  
							</label>												
							<label class="">
								{{ Form::Radio('emailSecurity','', $results['security']=='', array('id' => 'emailSecurity_noSegura','class' => 'radiobox')) }}
								<span>No segura</span> 
							</label>
						</div>
					</div>

					<div class="col-sm-4">
						<label><strong>Usuario</strong></label>
						<div class="form-group">
							<label class="checkbox-inline">
								{{ Form::Checkbox('userPassword',0, false, array('id' => 'userPassword','class' => 'checkbox style-0')) }}
								<span>Sin clave</span> 
							</label>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-6">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user fa-lg fa-fw"></i></span>
								{{ Form::text('emailUser',$results['username'],array('id' => 'emailUser', 'class' => 'form-control input-lg', 'placeholder' => 'usuario correo saliente' )) }}
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock fa-lg fa-fw"></i></span>
								{{ Form::password('emailPassword',array('id' => 'emailPassword', 'class' => 'form-control input-lg', 'placeholder' => 'clave correo' )) }}
							</div>
						</div>
					</div>
				</div>
				<br>
				<div class="row">
					<div class="col-sm-6">
						<div class="form-group">
							<h5><strong>
							<label class="checkbox-inline">
								{{ Form::Checkbox('emailActive',null,$results['active'], array('id' => 'emailActive','class' => 'checkbox style-0')) }}
								<span>Habilitar envio email</span>
							</label>
							</h5></strong>
						</div>
					</div>
					<div class="col-md-6">
						{{HTML::decode(Form::button('<i class="fa fa-envelope-o"></i> <strong>Prueba envio email</strong>',
							array('id' => 'submitTest','class' => 'btn btn-success','type' => 'button', 'name' => 'submitBtn', 'value' => 'emailTest'))) }}
					</div>
				</div>

		    </div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				<div class="form-actions">
					{{ HTML::decode(Form::button('<i class="fa fa-save"></i> <strong>Confirmar</strong>',
						array('id' => 'submitBtn','class' => 'btn btn-primary','type' => 'submit', 'name' => 'submitBtn', 'value' => 'emailSubmit'))) }}
				</div>
				<div class="col-md-12"><br></div>
			</div>
		</div>

		{{ Form::hidden('submitAction', null, array('id' => 'submitAction')) }}

	{{ Form::close() }}                     
</div>

<?php sleep(1) ?>

{{ HTML::script('js/plugin/ion.rangeSlider.min.js'); }}

<script type="text/javascript">
	@include('dashboard.library.gns_content')
</script>