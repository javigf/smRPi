<div class="col-sm-12">
    {{ Form::open(array('url' => 'configuracion','id' => 'ssrForm', 'novalidate' => 'novalidate', 'class' => 'register_ajax')) }}      
        
        <div class="tab-content">
            <div class="tab-pane active" id="tab1">
                <br>
                <h3><strong>Umbrales </strong> - Seleccione un Sensor de la lista</h3>
                <div class="row">
                    <div class="col-sm-offset-1 col-sm-10 col-sm-offset-1">
                         @include('dashboard.include.gns_select',array('name' => 'ssrId', 'id' => 'ssrId','result' => $results['sensors'], 'onChange' => 'selectOptn', 'disabled' => '', 'multiple' => ''))
                    </div>
                </div>
                <legend><h6>Seleccione los valores Máximos y Mínimos    </h6></legend>
                <div class="row">
                    <div class="col-sm-12">
                        <div id="ssrAdvise" class="alert alert-info hide" role="alert">
                            <h6>El sensor no admite valores maximos y minimos</h6>
                        </div>
                        <div id="ssrRange" class="form-group"></div>
                    </div>
                </div>
            
                <br>
                <h3><strong>Descripcion </strong> - Datos del Sensor</h3>
                <div class="row">

                    <div class="col-sm-5">
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-tachometer fa-lg fa-fw"></i></span>
                                {{ Form::text('name_sensor','Sensor',array('id' => 'name_sensor', 'class' => 'form-control input-lg','disabled' => 'disabled')) }}
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-5">
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-thumb-tack fa-lg fa-fw"></i></span>
                                {{ Form::text('grp_sensor','Grupo',array('id' => 'grp_sensor', 'class' => 'form-control input-lg','disabled' => 'disabled')) }}
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <label class="checkbox-inline">
                            {{ Form::Checkbox('ssrActive',1, false, array('id' => 'ssrActive','class' => 'checkbox style-0','disabled' => 'disabled')) }}
                            <span id="spanSsrActive" class=""><i class='fa  fa-lightbulb-o fa-3x'></i></span>
                        </label>
                    </div>

                </div>
                <div class="row">
                    
                    <div class="col-sm-8">
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-pencil-square-o fa-lg fa-fw "></i></span>
                                {{ Form::text('desc_sensor','Descripcion del sensor',array('id' => 'desc_sensor', 'class' => 'form-control input-lg','disabled' => 'disabled')) }}
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="form-group">
                            <div class="dropdown">
                                {{Form::button('<strong>Borrar Sensor</strong> <span class="caret"></span>',array('class' => 'btn dropdown-toggle btn-danger btn-lg btn-group-justified','disabled' => 'disabled', 'data-toggle' => 'dropdown', 'id' => 'dropdownSensorActions', 'aria-expanded' => 'true'))}}
                                <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownSensorActions" >
                                    <li id="contentDeleteSensor" role="presentation">
                                        <a id="linkDeleteSensor" role="menuitem" tabindex="-1" data-toggle="collapse" aria-expanded="false" aria-controls="collapseExample" > </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="hiddenRow">
                    <div id="ssrCfgCollapse" class="collapse" >
                        <div class="well">
                            <h4 class="text-danger">
                                <div class="alert alert-danger" role="alert"> <i><strong>Se borraran</strong> todos los datos del sensor, incluidas las alarmar que haya podido generar.<i></div><br>

                                {{Form::button('<strong>'.Config::get('app_texts.sensorDelete').'</strong>',array('id' => 'ssrCfgDeleteButton', 'class' => 'btn btn-danger'))}}
                                &nbsp&nbsp<strong id="ssrCfgDecSensor"> </strong>
                            </h4>

                        </div>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="form-actions">
                        {{ HTML::decode(Form::button('<i class="fa fa-save"></i> <strong>Confirmar</strong>',
                            array('id' => 'umbSubmit','class' => 'btn btn-primary','type' => 'submit','disabled' => 'disabled'))) }}
                    </div>
                    <div class="col-md-12"><br></div>
                </div>
            </div>
        </div>
    {{ Form::close() }}                     
</div>

