<meta charset="utf-8">
   
<title>Smart Monitor</title>
<meta name="description" content="Monitoreo Remoto Datacenter">
<meta name="author" content="GreenNetSite distribuido por LinkSolution">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="shortcut icon" href="img/favicon.png">
    
{{ HTML::style('css/bootstrap.min.css'); }}
{{ HTML::style('css/font-awesome.min.css'); }}
{{ HTML::style('css/gns_smartmonitor.css'); }}
{{ HTML::style('css/gns_style.min.css'); }}  

<link href="img/favicon/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="img/favicon/favicon.ico" rel="icon" type="image/x-icon">
