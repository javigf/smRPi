@section('gns_ribbon')

		<span class="ribbon-button-alignment"> 
			<span id="refresh" class="btn btn-ribbon" data-title="refresh"  rel="tooltip" data-placement="bottom" 
				data-original-title="<i class='text-warning fa fa-warning'></i> Atencion - Se borrara su configuracion de ventanas y regresara a la vista por defecto." 
				data-html="true" data-reset-msg="¿Esta seguro de BORRAR su configuración personalizada de ventanas?">
				<i class="fa fa-refresh"></i>
			</span>
		</span>

		<ol class="breadcrumb">
			<li>Inicio</li><li>{{ $breadcrumb }}</li>
		</ol>

		<div class="pull-right">
			<ol class="breadcrumb">
				<li class="text-uppercase"><i class="fa fa-user"></i>&nbsp;&nbsp;{{ Auth::user()->username }}</li> <li><small>{{ Config::get('app_globals.version') }} </small></li>
			</ol>
		</div>

@stop
