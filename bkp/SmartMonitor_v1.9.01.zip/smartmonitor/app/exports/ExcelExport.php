<?php 

ini_set('max_execution_time', 90);

class ExcelExport extends Fpdf
{
	private $items;

	public function getExport($parameters)
	{
		$this->items = $parameters['items'];
        $this->condition = $parameters['condition'];
        $this->status = $parameters['status'];
        $this->title = $parameters['title'];
        
		Excel::create("$this->title", function($excel)
		{
			$excel->setTitle('Smart Monitor Reportes')
				->setCreator('Smart Monitor')
          		->setCompany('Smart Monitor')
          		->setDescription('Reportes generados a travez del sistema.');

			$excel->sheet('Historico',function($sheet)
			{
				$data = array();
				$headers = $this->items[0];
				unset($headers['id_group']);

				array_push($data, array($this->title));
				array_push($data, array_keys($headers));

				$len = CHR(64+count($this->items[0]));

				foreach ($this->items as $key => $value) {
						
					if ($value['valor'] < 0 and $value['id_group'] == 'PT'){
						$value['valor'] = ($value['valor'] == -10) ? 'Abierta' : 'Cerrada';
					}
					
					unset($value['id_group']);
					array_push($data, $value);
					
					if ($value[$this->condition] == $this->status) {
						
						$cellsRange = 'A'.($key+3).':'.$len.($key +3);
						
						$sheet->cells($cellsRange, function($cells){
							$cells->setBackground('#FF8771')
								->setFontSize(10);
						});
					}
				}

				unset($data[0]['id_group']);
				$sheet->fromArray($data,null,'A1',false,false);
				$sheet->setFontSize(10);

				$sheet->mergeCells("A1:".$len.'1');
				$sheet->setHeight(1,25);

				$sheet->cells("A1", function($cells){
					$cells->setFontSize(14)
						->setValignment('middle')
						->setAlignment('center')
						->setFontWeight('bold');
				});
				$sheet->cells("A2:".$len.'2', function($cells){
					$cells->setValignment('middle')
						->setAlignment('center')
						->setFontWeight('bold');
				});

			});	

		})->export('xls'); 
	}

}

