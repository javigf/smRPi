<?php

class SensorsStatusTableSeeder extends Seeder {
	  
	public function run()
	{
		DB::table('sensors_status')->insert(array(
			'id'			=> '0',
			'description'	=> 'Sensor habilitado',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_status')->insert(array(
			'id'			=> '1',
			'description'	=> 'Sensor deshabilitado',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_status')->insert(array(
			'id'			=> '2',
			'description'	=> 'Nuevo Sensor detectado',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_status')->insert(array(
			'id'			=> '3',
			'description'	=> 'Nuevo hardware conectado',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_status')->insert(array(
			'id'			=> '4',
			'description'	=> 'Sensor en espera',
			'created_at' 	=> New DateTime,
		));

	}

}