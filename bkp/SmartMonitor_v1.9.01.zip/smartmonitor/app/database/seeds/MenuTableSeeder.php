<?php

class MenuTableSeeder extends Seeder {

	public function run()
	{
		
		DB::table('gns_menu')->insert(array(
		   'title'		=> 'Centros de Datos',
			'subtitle'	=> 'Nodos',
			'icon'		=> 'map-marker',
			'url'		=> 'nodos',
			'role_id'	=> 1,
			'description'=>'Visualiza Nodos de todos los CDC',
			'order'		=> 1,
			'created_at' => New DateTime,
		));

		DB::table('gns_menu')->insert(array(
			'title'		=> 'Panel de control',
			'subtitle'	=>'Monitoreo',
			'icon'		=>'tachometer',
			'url'		=> 'dashboard',
			'role_id'	=> 1,
			'description'=>'Dashboard: Informacion global de todos los sensores',
			'order'		=> 2,
			'created_at' => New DateTime,
		));


		DB::table('gns_menu')->insert(array(
			'title'		=> 'Alarmas',
			'subtitle'	=>'Registros históricos',
			'icon'		=>'bell',
			'url'		=> 'alarmas',
			'role_id'	=> 1,
			'description'=>'Detalle de las alarmas generadas por el sistema',
			'order'		=> 3,
			'created_at' => New DateTime,
		));


		DB::table('gns_menu')->insert(array(
			'title'		=> 'Gráficos',
			'subtitle'	=>'Registros ultimas 24 horas',
			'icon'		=>'bar-chart-o',
			'url'		=> 'graficos',
			'role_id'	=> 1,
			'description'=>'Graficos historicos de todos los sensores',
			'order'		=> 4,
			'created_at' => New DateTime,
		));


		DB::table('gns_menu')->insert(array(
			'title'		=> 'Registros del día',
			'subtitle'	=>'Sensores y alarmas',
			'icon'		=>'calendar-o',
			'url'		=> 'corriente',
			'role_id'	=> '1',
			'description'=>'Registros historicos de todos los sensores',
			'order'		=> 5,
			'created_at' => New DateTime,
		));


		DB::table('gns_menu')->insert(array(
			'title'		=> 'Registros históricos',
			'subtitle'	=>'Sensores y alarmas',
			'icon'		=>'calendar',
			'url'		=> 'historico',
			'role_id'	=> '1',
			'description'=>'Registros históricos de todos los sensores',
			'order'		=> 6,
			'created_at' => New DateTime,
		));

		DB::table('gns_menu')->insert(array(
			'title'		=> 'Configuración',
			'subtitle'	=>'Umbrales y Sensores',
			'icon'		=>'cogs',
			'url'		=> 'configuracion',
			'role_id'	=> '2',
			'description'=>'Configuracion del global del sistema y seleccion de graficos',
			'order'		=> 7,
			'created_at' => New DateTime,
		));

		DB::table('gns_menu')->insert(array(
			'title'		=> 'Usuarios',
			'subtitle'	=>'Abm de usuarios',
			'icon'		=>'users',
			'url'		=> 'usuarios',
			'role_id'	=> '2',
			'description'=>'Alta Baja Modificacion de usuarios del sistema',
			'order'		=> 8,
			'created_at' => New DateTime,
		));

	}

}
