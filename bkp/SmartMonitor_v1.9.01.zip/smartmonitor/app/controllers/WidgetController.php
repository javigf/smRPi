<?php

class WidgetController extends BaseController 
{

	public function __construct()
	{
		$this->beforeFilter('auth');
	}

	public function gns_constructWidget($metaWidget)
	{
		return View::make('dashboard.gns_widgets')
			->with('metaWidget',$metaWidget);
	}

}