<?php

class ErrorController extends BaseController 
{
	public static function errorPop($e)
	{
		echo $e;
		//View::make('error.errorPop');
		die();
	}

}