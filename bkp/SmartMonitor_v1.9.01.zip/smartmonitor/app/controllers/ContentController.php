<?php

use App\Models\Interfaces\NodeInterface;

class ContentController extends BaseController 
{
	private $alertsDispatcherController;
	private $WidgetContainer;
	private $formWidgetController;
	private $formController;
	private $emailController;
	private $node;


	public function __construct()
	{
		$this->WidgetContainer = App::make('WidgetContainer');
		$this->formWidgetController = App::make('formWidgetController');
		$this->formController = App::make('FormController');
		$this->alertsDispatcherController = App::make('AlertsDispatcherController');
		$this->emailController = App::make('EmailController');

		$this->node = Config::get('app_globals.sensorsNode');

	}


	public function gnsContent($sensorId = null,$contentId = null,$contentDiv = null,$range = null, $grphstyle = null, $grphcolor = null, $grphinterp = null, $unit = null)
	{
		if (is_null($contentId) || is_null($contentDiv)) {
			return View::make('error.error404');
			die();
		}

		return View::make('dashboard.content.gns_content_'.$contentId,array(
			'contentDiv' 	=> $contentDiv,
			'results'		=> $this->gnsRegistros($sensorId,$contentId,$range,$grphstyle,$grphcolor,$grphinterp,$unit),
			)	
		);
	}


	private function gnsRegistros($sensorId,$contentId,$range,$grphstyle,$grphcolor,$grphinterp,$unit)
	{
		switch ($contentId) {
			case '01':
				$results = $this->WidgetContainer->container();
			break;
			case '02':
				$results = $this->WidgetContainer->grphLstsRgtrs($sensorId,$range,$grphstyle,$grphcolor,$grphinterp);
			break;
			case '03':
				$results = $this->WidgetContainer->grphLsts1Rgtrs($sensorId);
			break;	
			case '04':
				$results[0] = $this->formController->getSelect($this->node,true);
				$results[1] = $sensorId;
				$results['colorBootstrap'] = $this->WidgetContainer->setColorBootstrap($grphcolor);
				array_shift($results[0]);
			break;
			case '05':
				$results = $sensorId;
			break;
			case '06':
				$results = $this->alertsDispatcherController->getActiveAlerts();
			break;
			case '07':
				$results = $this->emailController->setViewEmail();
			break;
			case '08':
				$results = $this->WidgetContainer->getDoorStatus($sensorId);
			break;
			case '10':
				$results[0] = $this->formWidgetController->getWidgets();
				$results[1] = $this->formController->getSelect($this->node,true);
				array_shift($results[1]);
			break;
			case '11':
				$results = $this->formController->getSelect($this->node);
			break;
			default:
				$results = '';
			break;
		}
		return $results;
	}
}

