<?php

class LayoutController extends BaseController 
{
	private $aside = array();
	private $menu;

	public function __construct()
	{
		$this->beforeFilter('auth');
	}

	public function getLayout($nav, $menu)
	{
		$layout = array(
			View::make('layouts.gns_aside',array(
				'nav' => $nav
				)
			),
			View::make('layouts.gns_header'),
			View::make('layouts.gns_ribbon')->withBreadcrumb($menu->title),
			View::make('layouts.gns_headerDash')->withMenu($menu),
		);

		return $layout;
	}

}