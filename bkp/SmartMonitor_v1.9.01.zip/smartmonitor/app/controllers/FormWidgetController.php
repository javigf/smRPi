<?php

use App\Models\Interfaces\GnsMetaWidgetInterface;

class FormWidgetController extends BaseController 
{
	
	private $gnsMetaWidget;

	public function __construct(GnsMetaWidgetInterface $gnsMetaWidget)
	{
		$this->beforeFilter('auth');
		$this->beforeFilter('role');
		
		$this->gnsMetaWidget = $gnsMetaWidget;

	}


	public function getIndex($formOptn,$id)
	{
		return self::$formOptn($id);
	}


	public function selectOptn($id)
	{
		$results = $this->gnsMetaWidget->getWidgetForm($id);		
		return Response::json($results);
	}


	public function getWidgets()
	{
		$results = array('' =>'Seleccione un WIDGET de la lista desplegable');

		$select = $this->gnsMetaWidget->getWidgetTitle();

		foreach ($select as $value) {
			$results[$value->id] = strtoupper($value->title).' '.$value->subtitle;
		}

		return $results;
	}


	public function postForm()
	{
		if(Request::ajax()){

			$input = Input::all();

			$reglas = array(
				'wgtId' 	=> 'required',
				'wgtTitle' 	=> 'required|min:3|max:25',
				'wgtIcon' 	=> 'required',
				'wgtSnsr'	=> 'required',
			);

			$validar = Validator::make($input, $reglas);

			if($validar->fails())
			{
				$message = $validar->messages()->first();
				$color = '#C46A69';
				$icon = 'thumbs-o-down';
			}
			else
			{
				$wgtUpdate = array(
	            	'wgtId' 			=> Input::get('wgtId'),
	            	'wgtTitle' 			=> Input::get('wgtTitle'),
	            	'wgtIcon' 			=> Input::get('wgtIcon'),
	            	'wgtMove' 			=> Input::get('wgtMove'),
					'wgtCollapsible' 	=> Input::get('wgtCollapsible'),
					'wgtClose' 			=> Input::get('wgtClose'),
					'wgtActive'			=> Input::get('wgtActive'),
					'wgtSnsr'			=> implode(',',Input::get('wgtSnsr')),
	        	);

				$update = $this->gnsMetaWidget->updWidget($wgtUpdate);

				if($update == 1){
					$message ='Widget: <strong>'.Input::get('wgtTitle').'</strong>, !! Se actualizo correctamente ¡¡';

					$color = '#739E73';
					$icon = 'thumbs-o-up';
				}
				else{
					$message ='NO SE HA REALIZADO La actualización';
					$color = '#C46A69';
					$icon = 'thumbs-o-down';
				}

			}		
			return Response::json(array('message' => $message,'color' => $color,'icon' => $icon));
		}/*else{
			return Redirect::to('/');
		}*/
	}
}

	