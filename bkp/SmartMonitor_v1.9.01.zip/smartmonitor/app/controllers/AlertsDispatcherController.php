<?php 

use App\Models\Interfaces\SensorRegistersInterface;
use App\Models\Interfaces\SensorInterface;
use App\Models\Interfaces\AlertsInterface;
use App\Models\Interfaces\GnsMetaWidgetInterface;

class AlertsDispatcherController extends BaseController 
{
	protected $sensorRegisters;
	protected $sensors;
	protected $sensorsAlerts;
	protected $emailController;
	protected $metaWidget;

	protected $response = array();	
	protected $updated = array();

	public function __construct(SensorRegistersInterface $sensorRegisters,SensorInterface $sensors, AlertsInterface $sensorsAlerts, GnsMetaWidgetInterface $metaWidget)
	{
		$this->sensorRegisters = $sensorRegisters;
		$this->sensors = $sensors;
		$this->sensorsAlerts = $sensorsAlerts;
		$this->metaWidget = $metaWidget;
		$this->emailController = App::make('EmailController');
	}


	public function getIndex($method,$id)
	{
		return self::$method($id);
	}


	public function configAlertsAllSensors()
	{
		$this->sensors->setNewIdStatus();
		$disconect = $this->sensors->setCommError(Config::get('app_globals.sensorTimeout'));
		$widget = $this->metaWidget->setGraphics();
		$sensors = $this->sensors->getAllSensors();

		if($sensors->count() > 0){
			$this->setAlertsSensor($sensors);
		}
		return $this->response;
	}
		

	public function setAlertsSensor($sensors)
	{
		$idUmbrales = array();
		
		foreach ($sensors as $value) {
				
			switch (true) {
				case $value->idStatus > 0:

					$this->sensorsAlerts->checkedAlertIdSensor($value->id,$value->idStatus);
					$this->putAlert($value->id,$value->sensorDescription,0,0,0,$value->statusDescription,$value->idStatus);
					break;

				case $value->idError < Config::get('app_globals.thresholdAlert'):

					$idUmbrales[] = $value->id;
					break;

				case $value->idError >= Config::get('app_globals.thresholdAlert'):
					$this->putAlert($value->id,$value->sensorDescription,0,0,0,$value->errorDescription,$value->idError);
					break;
			}
		}

		if(count($idUmbrales) > 0){
			$this->setAlerts($this->arrayToObject($this->sensorRegisters->getLast1Registers($idUmbrales)));	
		}
	}


	public function setAlerts($results)
	{
		$idError = 5;	
		foreach ($results as $key => $values) {

			switch (true){
				case $values->group == 'PT' and $values->val == -10:
						$descErr = "Apertura de puerta";
						$this->putAlert($values->id_sensor,$values->description,$values->val,$values->min,$values->max,$descErr,$idError);			
					break;
				
				case $values->group != 'PT' and $values->val > $values->max:
						$descErr = "Valor superior al rango Maximo configurado: Registro $values->val Maximo: $values->max";
						$this->putAlert($values->id_sensor,$values->description,$values->val,$values->min,$values->max,$descErr,$idError);
					break;

				case $values->group != 'PT' and $values->val < $values->min:
						$descErr = "Valor inferior al rango Minimo configurado Registro $values->val Minimo: $values->min";
						$this->putAlert($values->id_sensor,$values->description,$values->val,$values->min,$values->max,$descErr,$idError);
					break;

				default:
						$this->sensorsAlerts->checkedAlertIdSensor($values->id_sensor,Config::get('app_globals.sensorOk'));
						$this->sensors->setIdError($values->id_sensor,Config::get('app_globals.sensorOk'));
					break;
			}
		}
	}


	public function putAlert($idSensor, $description, $val, $min, $max, $descErr, $idError)
	{
		$this->updated = $this->sensorsAlerts->getUpdated();
	
		foreach ($this->updated as $key => $value) {
			if($value->id_sensor == $idSensor and $value->idError == $idError){
				$this->response[] = $this->sensorsAlerts->updAlert($idSensor,$val,$min,$max,$descErr,$value->updated+1);
				return $this->response;
			}
		}	

		$this->sensorsAlerts->checkedAlertIdSensor($idSensor,$idError);
		$this->response[] = $this->sensorsAlerts->putAlert($idSensor,$val,$min,$max,$descErr,$idError);

		$this->emailController->sendEmail($idSensor,$description, $val,$min,$max,$descErr, $idError,new DateTime());

		if ($idError == Config::get('app_globals.sensorDisabled') || $idError == Config::get('app_globals.sensorDetected')) {
			$idError = Config::get('app_globals.sensorOk');
		}
		
		$this->sensors->setIdError($idSensor,$idError);


	}


	public function setAlertNewIdSensor($idSensor)
	{
		$this->sensorsAlerts->checkedAlertNewIdSensor($idSensor);
	}


	public function getActiveAlerts()
	{
		return $this->sensorsAlerts->getActiveAlerts();
	}


	public function chkDoors($results)
	{
		$this->setAlertsSensor($results);
	}


    private function arrayToObject($array) 
    {
		if (is_array($array)){
			return (object) array_map('self::'.__FUNCTION__, $array);
		}
		else{
			return $array;
		}
	}


	public function checkedAlert($id)
	{

		$results = $this->sensorsAlerts->checkedAlerts($id);

		if($results == 1){
			$box = array(
				'message' 	=> 'Alerta: '.$id.', ! Se actualizo correctamente ¡',
				'color' 	=> '#739E73',
				'icon' 		=> 'up',
			);
		}
		
		return Response::json($box);
	}

}
