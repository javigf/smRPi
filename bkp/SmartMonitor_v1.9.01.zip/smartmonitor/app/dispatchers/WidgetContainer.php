<?php 

use App\Models\Interfaces\SensorRegistersInterface;
use App\Models\Interfaces\FormatsInterface;
use App\Models\Interfaces\GrphsFormatInterface;
use App\Models\Interfaces\NodeInterface;
use App\Models\Interfaces\SensorGroupInterface;


class WidgetContainer extends BaseController 
{
	private $sensorRegisters;
	private $sensorGroup;
	private $node;
	private $formats; 
	private $grphsFormatInterface;
	private $jsnGrph;
	private $query;
	private $alertsDispatcherController;


	public function __construct(SensorRegistersInterface $sensorRegisters, FormatsInterface $formats, GrphsFormatInterface $grphsFormatInterface, NodeInterface $node, SensorGroupInterface $sensorGroup/*, SensorInterface $sensor*/)
	{
		$this->sensorRegisters = $sensorRegisters;
		$this->formats = $formats;
		$this->grphsFormatInterface = $grphsFormatInterface;
		$this->node = $node;
		$this->sensorGroup = $sensorGroup;
		$this->alertsDispatcherController = App::make('AlertsDispatcherController');
	}


	public function container()
	{
		$nodes[0] = $this->node->getNodes();
		$nodes[1] = $this->sensorGroup->getSensorGroup();
		$nodes[2] = $this->sensorRegisters->getNodeSensorsRegisters();
		
		$results = array_merge($nodes[0],$nodes[1],$nodes[2]);
		
		return json_encode($results);
	}


	public function grphLstsRgtrs($idSensor,$range,$style,$color,$interp)
	{
		$this->query = $this->sensorRegisters->getLastsRegisters($idSensor,$range);
		
		if (count($this->query) > 0) {
			
			self::getMapTime();	
			self::formatQuery($range);	
			$objGrph = self::arrayToObject($this->jsnGrph);

			$objGrph->style = $this->grphsFormatInterface->getGrphStyle($style);	
			$objGrph->color = $this->grphsFormatInterface->getGrphColor($color);
			$objGrph->interp = $this->grphsFormatInterface->getGrphInterp($interp);

			return $objGrph;
		}
	}


	public function getDoorStatus($idSensor)
	{
		$idSensor = explode(',',$idSensor);

		$this->query = self::arrayToObject($this->sensorRegisters->getLast1Registers($idSensor));
		if (!empty((array)$this->query)) {

			$objDoor = self::arrayToObject($this->query);

			$this->alertsDispatcherController->chkDoors($objDoor);

			return $objDoor;
		}
		else return null;
	}


	public function grphLsts1Rgtrs($idSensor)
	{
		$idSensor = explode(',',$idSensor);
		$this->query = self::arrayToObject($this->sensorRegisters->getLast1Registers($idSensor));

		if (!empty((array)$this->query)) {
					
			self::formatQuery(1);
			$objGrph = self::arrayToObject($this->jsnGrph);

			return $objGrph;
		}
		else return null;
	}

	private function getMapTime()
	{
		$time = array();
		$sensors = array();
		$map = array();

		foreach ($this->query as $pos => $values) {
			$time[$pos] = $values->date;
			$sensors[] = $values->id_sensor;
		}
		$time = array_flip(array_values(array_unique($time)));			
		$sensors = array_values(array_unique($sensors));
		
		foreach ($time as $keyTm => $valueTm) {
			foreach ($sensors as $keySsrs => $valueSsrs) {
				$this->jsnGrph['map'][$valueSsrs][$keyTm] = 0;
			}
		}
	}

	private function formatQuery($range)
	{
		foreach ($this->query as $pos => $values) {
			foreach ($values as $key => $value) {
				if($key != 'id_sensor'){
					if ($range == 1 || $key == 'description' || $key == 'unit') {
						$this->jsnGrph['id'][$values->id_sensor][$key] = $value;	
					}elseif($key != 'date'){
						$this->jsnGrph['id'][$values->date][$values->id_sensor][$key] = $value;
						$this->jsnGrph['map'][$values->id_sensor][$values->date] = $value;			

					}
				}	
			}
		}
	}

	public function setColorBootstrap($color)
	{
		return $this->grphsFormatInterface->getColorBootstrap($color);
	}


    private function arrayToObject($array) 
    {
		if (is_array($array)) {
			return (object) array_map('self::'.__FUNCTION__, $array);
		}
		else {
			return $array;
		}
	}

}
