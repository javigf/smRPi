<?php

use App\Models\Interfaces\SensorInterface;

class FormTableFilter extends BaseController 
{
	
	private $sensors;

	public function __construct(SensorInterface $sensors)
	{
		$this->sensors = $sensors;
	}


	public function getSensors()
	{
		$results =  $this->sensors->getAllSensors(90);

		if($results->count() > 0)
		{
			foreach ($results as $key => $value) {
				 $sensorsId[] = $value->id;
			}
		}else{
			$sensorsId[] = '';
		}

		return $sensorsId;
	}


	public function postForm()
	{
		
		Session::forget('sensorsId');
		Session::forget('values');
		Session::forget('doors');
		Session::forget('dates');
		Session::forget('times');

		$doors = 0;
		if(Request::ajax()){

			if (is_null(Input::get('ftrTblSensor'))) {
				Session::put('sensorsId',$this->getSensors());
			}else{
				Session::put('sensorsId', Input::get('ftrTblSensor'));
			}
			
			Session::put('values', explode(';',Input::get('ftrTblValues')));
			Session::put('doors', $doors);

			$ftrTblFrom = Input::get('ftrTblFrom');
			$ftrTblTo = Input::get('ftrTblTo');

			if (empty(Input::get('ftrTblFrom'))) {
				$ftrTblFrom = date('2012/01/01');
			}
			if (empty(Input::get('ftrTblTo'))) {
				$ftrTblTo = date('Y/m/d');
			}
			Session::put('dates',array($ftrTblFrom, $ftrTblTo));

			$ftrTblFromHr = Input::get('ftrTblFromHr');
			$ftrTblToHr = Input::get('ftrTblToHr');

			if (empty(Input::get('ftrTblFromHr'))) {
				$ftrTblFromHr = '00:00';
			}
			if (empty(Input::get('ftrTblToHr'))) {
				$ftrTblToHr = '23:59:59';
			}
			Session::put('times',array($ftrTblFromHr, $ftrTblToHr));

			$message ='Corriendo busqueda ¡¡ ';
			$color = '#739E73';
			$icon = 'search';
			
			return Response::json(array('message' => $message,'color' => $color,'icon' => $icon));
		}else{
			return Redirect::to('/');
		}
	}

}

	