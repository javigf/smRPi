<?php

class FormUser extends BaseController 
{
	
	private $users;
	private $validar;
	private $data = array();

	public function __construct()
	{
		$this->users = new user();
	}


	public function posDelUser()
	{
		if(Request::ajax()){
			$id = Input::get('id');

			$result = $this->users->delUser($id);
		}else{
			return Redirect::to('/');
		}
	}

	public function postForm()
	{
		if(Request::ajax()){

			$input = Input::all();
			$id = Input::get('usrId');
			$usrPwd = Input::get('usrPwd');

			if(is_null($usrPwd)){
				$rules = array(
					'userFirstName' => 'required|min:5|max:25',
					'userLastName' 	=> 'required|min:3|max:25',
					'userEmail' 	=> 'required|min:5|max:100|email|unique:gns_users,email,'.$id,
					'userName'		=> 'required|min:5|max:20|unique:gns_users,username,'.$id,
					'usrRole'		=> 'required',
				);
			}

			if(is_null($id)){
				$rules['userPassword1'] = 'required|min:5|max:20|';
				$rules['userPassword2'] = 'required|same:userPassword1';
			}

			$validar = Validator::make($input, $rules);

			if($validar->fails())
			{
				$message = $validar->messages()->first();
				$color = '#C46A69';
				$icon = 'thumbs-o-down';
				$action = 'error';
			}else{
				if(!is_null($usrPwd)){
					$results = $this->users->updPwdUser(Input::all());
				}elseif(is_null($id)){
					$results = $this->users->addUser(Input::all());
				}else{
					$results = $this->users->updUser(Input::all());
				}

				$color = '#739E73';
				$icon = 'thumbs-o-up';

				if(isset($results->id)){
					$message ='El usuario : <strong>'.Input::get('userName').'</strong>, !!Se creo correctamente¡¡';
					$action = 'add';
				}elseif(is_numeric($results) && $results == 1){
					$message ='El usuario : <strong>'.Input::get('userName').'</strong>, !!Se actualizo correctamente¡¡';
					$action = 'upd';
				}else{
					$results = (is_object($results) ? $results->getCode() : $results );
					Log::error($results);
					$message = 'Error: '.$results.' NO SE HA REALIZADO La actualización';
					$color = '#C46A69';
					$icon = 'thumbs-o-down';
					$action = 'error';
				}

			}		
			return Response::json(array('message' => $message,'color' => $color,'icon' => $icon,'action' => $action));
		}else{
			return Redirect::to('/');
		}
	}

}

	