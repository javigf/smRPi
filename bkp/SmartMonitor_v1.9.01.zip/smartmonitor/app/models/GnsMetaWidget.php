<?php 

namespace App\Models;

use App\Models\Interfaces\GnsMetaWidgetInterface;
use Eloquent;
use DB;

class GnsMetaWidget extends Eloquent implements GnsMetaWidgetInterface
{

	protected $connection = 'local';

	public function getWidgetContruct($menu_id)
	{
		$results = GnsMetaWidget::where('menu_id','=',$menu_id)
			->where('active','=',1)
			->orderby('sequence')
			->get(array('id', 'menu_id', 'content_id', 'icon', 'color', 'title', 'subtitle', 'move', 'collapsible', 'close', 'col_lg',
						'sequence', 'sensors_id', 'range', 'grphstyle', 'grphcolor', 'grphinterp','unit', 'refresh')
				)
			->toArray();
			
		return $results;
	}

	public function getWidgetTitle()
	{
		$results = GnsMetaWidget::where('modify','=',1)
			->orderby('sequence')
			->get(array('id','title','subtitle'));

		return $results;
	}


	public function getWidgetForm($id)
	{
		$results = GnsMetaWidget::where('gns_meta_widgets.id','=',$id)
			->where('modify','=',1)
			->get(array('menu_id', 'content_id', 'icon', 'color', 'title', 'subtitle', 'move', 'collapsible', 'close', 'col_lg',
				'sequence', 'sensors_id', 'range', 'grphstyle', 'grphcolor', 'grphinterp', 'unit', 'refresh','active'));
			
		return $results[0];
	}


	public function updWidget($wgtUpdate)
	{
		try{
			$result =  GnsMetaWidget::where('id', '=', $wgtUpdate['wgtId'])
				->update(array(	'title' 		=> $wgtUpdate['wgtTitle'],
								'icon' 			=> $wgtUpdate['wgtIcon'],
								'move'		 	=> $wgtUpdate['wgtMove'],
								'collapsible' 	=> $wgtUpdate['wgtCollapsible'],
								'close' 		=> $wgtUpdate['wgtClose'],
								'active' 		=> $wgtUpdate['wgtActive'],
								'sensors_Id'	=> $wgtUpdate['wgtSnsr'],
					));
			return $result;
		} catch (\Exception $e) {
			return 0;			
		}

	}


	public function setGraphics()
	{
		try{
			$result = DB::statement("update gns_meta_widgets mw
						inner join sensors s on sensors_id like concat('%',s.id,'%')
						set active = 1,
						col_lg = (select if(count(1) > 4,12,6) 
								from sensors s1 
								where s1.id_status = 0 and s.id_group = s1.id_group)
						where mw.modify = 1  and s.id_status = 0 and menu_id = 2 and mw.content_id <> 8");

			$result = DB::statement("update gns_meta_widgets mw
						inner join sensors s on sensors_id like concat('%',s.id,'%')
						set active = 1,
						col_lg = (select if(count(1) < 3,4,6) 
								from sensors s1 
								where s1.id_status = 0 and s.id_group = s1.id_group)
						where mw.modify = 1 and s.id_status = 0 and menu_id = 2 and mw.content_id = 8");
			

			$result = DB::statement("update gns_meta_widgets mw
							inner join sensors s on sensors_id like concat('%',s.id,'%')
							set active = 1
							where modify = 1 and active = 0 and s.id_status = 0 and menu_id = 4");


			$result = DB::statement("update gns_meta_widgets mw
							inner join sensors s  on  sensors_id like concat('%',s.id,'%')
							set active = 0
							where modify = 1 and active = 1 
							and length(replace(sensors_id,',','')) = (select(count(s1.id)*6) from sensors s1 
																	where s1.id_group = s.id_group and s1.id_status > 0
																	group by id_group)");

			return $result;
		} catch (\Exception $e) {
			return 0;			
		}

	}
}