<?php 

namespace App\Models;

use App\Models\Interfaces\SensorsRegistersHistoryInterface;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableInterface;
use Eloquent;
use DB;
use LOG;

class SensorsRegistersHistory extends Eloquent implements SensorsRegistersHistoryInterface 
{
	protected $table = 'sensors_registers_history';

	public function getTTable($itemsPerPage,$sensorsId,$values,$doors, $dates)
	{
		$results = SensorsRegistersHistory::orderBy('id','desc')
			->select('id','id_sensor as sensor','description as descripcion','id_group','value as valor','min','max','alert','date as fecha','time as hora')
			->whereIn('id_sensor',$sensorsId) 
			->where(function($query) use ($values,$doors)
			{
				$query->whereBetween('value',$values);
				//$query->orWhere('value','<',$doors);
				$query->orWhere('id_group','=','PT'); // Version 1.8.2
			}) 
			->whereBetween('date',$dates)
			->paginate($itemsPerPage);

		return $results;
	}


	public function getExport($itemsPerPage,$sensorsId,$values,$doors,$dates)
	{
		$results = SensorsRegistersHistory::orderBy('id','desc')
			->select('id_sensor as sensor','description as descripcion','id_group','value as valor','min','max','alert','date as fecha','time as hora')
			->whereIn('id_sensor',$sensorsId) 
			->where(function($query) use ($values,$doors)
			{
				$query->whereBetween('value',$values);
				//$query->orWhere('value','<',$doors);
				$query->orWhere('id_group','=','PT'); // Version 1.8.2
			}) 
			->get()
			->take(20000)
			->toArray();

		return $results;
	}


	public function putHistRegisters($ids)
	{
		try{
			DB::beginTransaction();
			DB::connection()->disableQueryLog();
			
			$id = implode(',',$ids);


			$query = DB::statement( "insert into sensors_registers_history(id, id_sensor, description, id_group, value, min, max, alert, date, time, created_at)
				select sr.id,id_sensor, description, id_group, if(id_group <> 'PT',format(avg(registro),1),registro), min, max,2, date_format(sr.created_at,'%Y/%m/%d') date , date_format(sr.created_at,'%H:%i') time,now()
				from sensores_registros sr inner join sensors s
				on sr.id_sensor = s.id
				where sr.created_at < DATE_SUB(CURDATE(),INTERVAL 0 DAY)
				and sr.id not in ($id)
				group by id_sensor,date, time,
				if(id_group <> 'PT',time,date_format(sr.created_at,'%H:%i:%s'))
					order by sr.id desc");

			//Log::info("putHistRegisters 1-> $query");


			$query = DB::statement("update sensors_registers_history
						set alert = 1
						where alert = 2
						and (((value < min or value > max) and id_group <> 'PT') or (value = -10 and id_group = 'PT'))");

			//Log::info("putHistRegisters 2-> $query");


			$query = SensorsRegistersHistory::where('alert','=',2)
				->update(array('alert' => 0));

			//Log::info("putHistRegisters 3-> $query");


			$query = DB::table('sensores_registros')
				->where('created_at','<',DB::raw('DATE_SUB(CURDATE(),INTERVAL 0 DAY)'))
				->whereNotIn('id',$ids)
				->delete();

			//Log::info("putHistRegisters 4-> $query");


			DB::commit();
			return $query;

		}  catch (\Illuminate\Database\QueryException $e) {
			DB::rollback();
			Log::error("putHistRegisters -> ".$e);
			return "ERROR EN PROCESAR REGISTROS HISTORICOS\n";
		}
	}

}