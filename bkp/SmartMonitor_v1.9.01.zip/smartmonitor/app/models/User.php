<?php

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;


class User extends Eloquent implements UserInterface, RemindableInterface
{

	use UserTrait, RemindableTrait;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'gns_users';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = array('password', 'remember_token');


	public function addUser(array $inputAll)
	{
		try {
			$result = new User;
			$result->first_name = $inputAll['userFirstName'];
			$result->last_name = $inputAll['userLastName'];
			$result->email = $inputAll['userEmail'];
			$result->username = $inputAll['userName'];
			$result->password = Hash::make($inputAll['userPassword2']);
			$result->role_id = $inputAll['usrRole'];
			$result->created_at = New DateTime;
			$result->save();

			return $result;
		} catch (\Illuminate\Database\QueryException $e) {
			 return $e;
		}
	}


	public function updUser($inputAll)
	{
		try{
			$result =  User::where('id', '=', $inputAll['usrId'])
				->update(array(	'first_name' => $inputAll['userFirstName'],
								'last_name' => $inputAll['userLastName'],
								'email'		=> $inputAll['userEmail'],
								'username' 	=> $inputAll['userName'],
								'role_id' 	=> $inputAll['usrRole'],
					));

			return $result;
		} catch (\Illuminate\Database\QueryException $e) {
			 return $e;
		}

	}


	public function updPwdUser($inputAll)
	{
		try{
			$result =  User::where('username', '=', $inputAll['userName'])
				->update(array(	'password' => Hash::make($inputAll['userPassword2']),
					));

			return $result;
		} catch (\Illuminate\Database\QueryException $e) {
			 return $e;
		}

	}


	public function delUser($id)
	{
		try{
			$result = User::find($id);
			$result->delete();

			return true;
		} catch (\Illuminate\Database\QueryException $e) {
			return false;
		}
	}


	public function getAllusers()
	{
		$results = user::where('id','>',1)
		->get(array('id','first_name','last_name','email','username','role_id'))
		->toArray();

		return $results;
	}


	public function getIdUser($id)
	{
		$results = user::where('id','=',$id)
		->get(array('id','first_name','last_name','email','username','role_id'))
		->toArray();

		return $results;
	}

}
