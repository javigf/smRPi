<?php 

namespace App\Models;

use App\Models\Interfaces\FormatsInterface;

class Formats  implements FormatsInterface
{

	public function getDay()
	{
		return '%Y%m%d';
	}
	
	public function getHour()
	{
		return self::getDay().'%h';
	}

	public function getMinute()
	{
		return self::getHour().'%i';
	}

}