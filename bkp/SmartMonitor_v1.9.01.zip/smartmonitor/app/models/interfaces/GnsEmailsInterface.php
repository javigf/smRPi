<?php 

namespace App\Models\Interfaces;

interface GnsEmailsInterface
{
	public function getEmails($id);

	public function updEmail($input,$id);

}