<?php 

namespace App\Models\Interfaces;

interface SensorGroupInterface
{
	public function getSensorGroup($id = null);

	public function getSelectGrp($id_nodo);
}

