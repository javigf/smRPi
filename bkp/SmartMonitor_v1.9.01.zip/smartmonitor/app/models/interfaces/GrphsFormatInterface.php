<?php 

namespace App\Models\Interfaces;

interface GrphsFormatInterface
{
	public function getGrphStyle($id);

	public function getGrphColor($id);

	public function getGrphInterp($id);

}
