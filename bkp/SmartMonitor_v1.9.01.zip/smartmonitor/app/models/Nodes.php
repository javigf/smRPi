<?php

namespace App\Models;

use App\Models\Interfaces\NodeInterface;
use Eloquent;



class Nodes extends Eloquent implements NodeInterface
{

	public function getNodes($id = null)
	{
		$result = Nodes::get(array('id as name','parent', 'description as alias','path'))
		->toArray();

		return $result;
	}


}
