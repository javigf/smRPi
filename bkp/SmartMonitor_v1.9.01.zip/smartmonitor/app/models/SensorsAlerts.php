<?php

namespace App\Models;

use App\Models\Interfaces\AlertsInterface;
use Eloquent;
use DB;


class SensorsAlerts extends Eloquent implements AlertsInterface
{
	//public $incrementing = 'false';


	public function putAlert($sensorId,$val,$min,$max,$desc,$idError)
	{
		try{
			$result = new SensorsAlerts;

			$result->id_sensor = $sensorId;
			$result->registro = $val;
			$result->min = $min;
			$result->max = $max;
			$result->description = $desc;
			$result->checked = 0;
			$result->id_error = $idError;
			$result->save();

			return $result;
		} catch (\Exception $e) {
			return $e;			
		}
		
	}


	public function updAlert($sensorId,$val,$min,$max,$desc,$updated)
	{
		try{
			$result =  SensorsAlerts::where('id_sensor', '=',$sensorId)
				->where('checked','=', 0)
				->update(array(	'registro' 	=> $val,
							'min' 			=> $min,
							'max'		 	=> $max,
							'description'	=> $desc,
							'updated'		=> $updated,
		));
			return "Updated $result Sensor Alertado: $sensorId";
		} catch (\Exception $e) {
			return $e;			
		}
		
	}


	public function getTTable($itemsPerPage,$sensorsId,$values,$doors,$dates)
	{
		$results = SensorsAlerts::join('sensors','sensors.id','=','sensors_alerts.id_sensor')
		->select('sensors_alerts.id as idAlerta', 'sensors_alerts.id_sensor as sensor', 'sensors.description', 'sensors.id_group', 'registro as valor', 'sensors_alerts.description as Error', 'sensors_alerts.min', 'sensors_alerts.max',
						'checked','updated as Actualizado', DB::raw("date_format( sensors_alerts.updated_at,'%Y/%m/%d') as Fecha") , DB::raw("date_format(sensors_alerts.updated_at,'%H:%i') as Hora"))
		->whereIn('id_sensor',$sensorsId)
		->where(function($query) use ($values,$doors)
		{
			$query->whereBetween('registro',$values);
			//$query->orWhere('registro','<',$doors);
			$query->orWhere('id_group','=','PT'); // Version 1.8.2
		}) 
		->whereBetween(DB::raw("date_format( sensors_alerts.updated_at,'%Y/%m/%d')"),$dates)
		->orderBy('Fecha','desc')
		->orderBy('Hora','desc')
		->paginate($itemsPerPage);


		return $results;
	}


	public function getExport($itemsPerPage,$sensorsId,$values,$doors,$dates)
	{
		$results = SensorsAlerts::join('sensors','sensors.id','=','sensors_alerts.id_sensor')
		->select('sensors_alerts.id_sensor as sensor', 'sensors.description', 'registro as valor', 'sensors_alerts.description as Error', 'sensors.id_group', 'sensors_alerts.min', 'sensors_alerts.max',
						'checked','updated as Act.', DB::raw("date_format( sensors_alerts.updated_at,'%Y/%m/%d') as Fecha") , DB::raw("date_format(sensors_alerts.updated_at,'%H:%i') as Hora"))
		->whereIn('id_sensor',$sensorsId)
		->where(function($query) use ($values,$doors)
		{
			$query->whereBetween('registro',$values);
			//$query->orWhere('registro','<',$doors);
			$query->orWhere('id_group','=','PT'); // Version 1.8.2
		}) 
		->whereBetween(DB::raw("date_format( sensors_alerts.updated_at,'%Y/%m/%d')"),$dates)
		->orderBy('Fecha','desc')
		->orderBy('Hora','desc')
		->get()
		->toArray();

		return $results;
	}
	

	public function getUpdated()
	{
		$results = SensorsAlerts::Where('checked','=',0)
		->orderBy('id_sensor','desc')
		->get(array('id_sensor','updated', 'id_error as idError'));

		return $results;
	}


	public function getActiveAlerts()
	{
		$results = SensorsAlerts::join('sensors','sensors.id','=','sensors_alerts.id_sensor')
		->select('sensors_alerts.id as idAlerta','sensors_alerts.id_sensor as sensor', 'sensors.description', 'registro as valor', 'sensors_alerts.description as Error',
			'sensors_alerts.min', 'sensors_alerts.max','sensors.id_error as idError',
			'updated as Act.', DB::raw("date_format( sensors_alerts.updated_at,'%Y/%m/%d') as Fecha") , DB::raw("date_format(sensors_alerts.updated_at,'%H:%i') as Hora"))
		->Where('checked','=',0)
		->orderBy('sensors_alerts.created_at','desc')
		->get();

		return $results;
	}


	public function checkedAlerts($id)
	{
		try {
			$results =  SensorsAlerts::where('id', '=', $id)
				->update(array('checked' => 1));	

			return $results;

		} catch (Exception $e) {
			return 0;
		}
		
	}


	public function checkedAlertIdSensor($id,$idError)
	{
		try {
			$results =  SensorsAlerts::where('id_sensor','=',$id)
				->where('checked','=',0)
				->where('id_error','<>',$idError)
				->update(array('checked' => 1));	

			return $results;

		} catch (Exception $e) {
			return 0;
		}
		
	}

	public function checkedAlertNewIdSensor($id)
	{
		try {
			$results =  SensorsAlerts::where('id_sensor','=',$id)
				->where('checked','=',0)
				->whereIn('id_error',array(1,2)) 
				->update(array('checked' => 1));	

			return $results;

		} catch (Exception $e) {
			return 0;
		}
		
	}

}




