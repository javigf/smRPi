<?php 

namespace App\Models;

use App\Models\Interfaces\SensorRegistersInterface;

use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableInterface;
use Eloquent;
use DB;

class SensoresRegistros extends Eloquent implements SensorRegistersInterface
{
	public function getNodeSensorsRegisters($id = null)
	{	
		$results = SensoresRegistros::join(DB::raw('(select id_sensor, max(id) id from sensores_registros group by id_sensor) sr2'),function($join)
				{
					$join->on('sensores_registros.id','=','sr2.id');
				})
			->rightJoin('sensors','sensores_registros.id_sensor','=','sensors.id')
			->join('sensors_groups','sensors_groups.id','=','sensors.id_group')
			->join('sensors_errors','sensors_errors.id','=','sensors.id_error')
			->join('sensors_status','sensors_status.id','=','sensors.id_status')
			->where('id_status','<', 3)
			->orderBy('sensores_registros.id_sensor')
			->selectRaw('concat(id_node,id_group,sensors.id) name ,concat(sensors.id_node,id_group) parent, sensors.id sensor, sensors.description alias, 
						case when (id_group = "PT" and registro = -10) then "Puerta Abierta" when (id_group = "PT" and registro = -20) then "Puerta Cerrada" else coalesce(registro,"----") end as register,unit,
						sensors_errors.description error,sensors_errors.id idError,sensors.id_status as idStatus,sensors_status.description as statusDescription,max,min,
						case when ((registro > max or registro < min) and id_group <> "PT") then 1 when (id_group = "PT" and registro = -10) then 1 else 0 end as alert')
			->get()
			->toArray();

		return $results;
	}


	public function getLastsRegisters($sensorId,$range)
	{
		$sensorId = str_replace(',', "','", $sensorId);

		$results = DB::select("select id_sensor, format(avg(registro),1) as val, date_format(sq1.created_at,'%H:%i') date, sensors_groups.unit, sensors.description		
					from (select id, id_sensor, registro, created_at, @num := if(@sensor = id_sensor, @num + 1, 1) as cant, @sensor := id_sensor as sensor
					FROM sensores_registros 
					ORDER BY id_sensor, id desc) AS sq1
					inner join sensors on sensors.id = sq1.id_sensor
					inner join sensors_groups on sensors_groups.id = sensors.id_group
					where id_sensor in ('$sensorId')
					and id_status = 0
					and cant <= ?
					group By sq1.id_sensor,date
					order by sq1.id;", array($range));

		return $results;
	}


	public function getLast1Registers($sensorId)
	{
		$results = DB::table(DB::raw("(select id, id_sensor, registro, created_at, @num := if(@sensor = id_sensor, @num + 1, 1) as cant, @sensor := id_sensor as sensor
					FROM sensores_registros 
					ORDER BY id_sensor, id desc) AS sq1"))
			->join('sensors','sensors.id','=','sq1.id_sensor')
			->join('sensors_groups','sensors_groups.id','=','sensors.id_group')
			->join('sensors_errors','sensors_errors.id','=','sensors.id_error')
			->whereIn('id_sensor',$sensorId)
			->where('cant','<=',1)	
			->where('sensors.id_status','=', 0)
			->groupBy('sq1.id_sensor','sq1.id')
			->orderBy('sq1.id')
			->get(array('id_sensor','registro as val','sensors.description','sensors_groups.unit','sensors_groups.id as group','max','min','sensors.id_error',
						'sensors_errors.description as descError','sensors.id_status as idStatus',
						/*CHANCHADA*/
						'sensors.id_error as idError', 'id_sensor as id','sensors.description as sensorDescription','sensors_errors.description as errorDescription'));
			
		return $results;
	}


	public function getMaxIdSensor()
	{
		$results = SensoresRegistros::join('sensors','sensores_registros.id_sensor','=','sensors.id')
		->selectRaw('max(sensores_registros.id) as id')
		->where('sensores_registros.created_at','<',DB::raw('DATE_SUB(CURDATE(),INTERVAL 0 DAY)'))
		->where('sensors.id_status','<', 4)
		->groupBy('sensores_registros.id_sensor')
		->get();

		return $results;
	}


	public function getTTable($itemsPerPage,$sensorsId,$values,$doors,$dates,$times)
	{
		$results = SensoresRegistros::join('sensors','sensores_registros.id_sensor','=','sensors.id')
			->select('sensores_registros.id', 'id_sensor as sensor', 'description as descripcion', 'sensors.id_group', DB::raw('if(id_group <> "PT",format(avg(registro),1),registro)  as valor'),'min','max',
				DB::raw('case when ((avg(registro) > max or avg(registro) < min) and id_group <> "PT") then 1 when (id_group = "PT" and registro = -10) then 1 else 0 end as alert'),
				DB::raw("date_format( sensores_registros.created_at,'%Y/%m/%d') as Fecha") , DB::raw("date_format(sensores_registros.created_at,'%H:%i') as Hora"))
			->whereIn('id_sensor',$sensorsId)
			->where(function($query) use ($values,$doors)
			{
				$query->whereBetween('registro',$values);
				//$query->orWhere('registro','<',$doors);
				$query->orWhere('id_group','=','PT'); // Version 1.8.2
			}) 
			->whereBetween(DB::raw("date_format(sensores_registros.created_at,'%H:%i')"),$times)
			->groupBy('id_sensor','Fecha',DB::raw("if(id_group <> 'PT',Hora,date_format(sensores_registros.created_at,'%H:%i:%s'))"))
			->orderBy('sensores_registros.id','desc')
			->paginate($itemsPerPage);

		return $results;
	}


	public function getExport($itemsPerPage,$sensorsId,$values,$doors,$dates,$times)
	{
		$results = SensoresRegistros::join('sensors','sensores_registros.id_sensor','=','sensors.id')
			->select('id_sensor as sensor', 'description as descripcion', 'sensors.id_group', DB::raw('if(id_group <> "PT",format(avg(registro),1),registro)  as valor'),'min','max',
				DB::raw('case when ((avg(registro) > max or avg(registro) < min) and id_group <> "PT") then 1 when (id_group = "PT" and registro = -10) then 1 else 0 end as alert'),
				DB::raw("date_format( sensores_registros.created_at,'%Y/%m/%d') as Fecha") , DB::raw("date_format(sensores_registros.created_at,'%H:%i') as Hora"))
			->whereIn('id_sensor',$sensorsId)
			->where(function($query) use ($values,$doors)
			{
				$query->whereBetween('registro',$values);
				//$query->orWhere('registro','<',$doors);
				$query->orWhere('id_group','=','PT'); // Version 1.8.2
			}) 
			->whereBetween(DB::raw("date_format(sensores_registros.created_at,'%H:%i')"),$times)
			->groupBy('id_sensor','Fecha',DB::raw("if(id_group <> 'PT',Hora,date_format(sensores_registros.created_at,'%H:%i:%s'))"))
			->orderBy('sensores_registros.id','desc')
			->get()
			->take(20000)
			->toArray();

		return $results;
	}


	public function addregister($id,$registro){
		try{
			$sensor =  new SensoresRegistros;
			$sensor->id_sensor = $id;
			$sensor->registro = $registro;
 			$sensor->save();	

 			return $sensor;
		} catch (\Exception $e) {
			return $e;			
		}
	}

}
