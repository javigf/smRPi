<?php

return array(

	'driver' => 'smtp',
	'host' => '',
	'port' => '',
	'from' => '',
	'encryption' => '',
	'username' => '',
	'pretend' => false,

);
