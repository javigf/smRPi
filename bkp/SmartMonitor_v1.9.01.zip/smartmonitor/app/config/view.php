<?php

return array(

	'paths' => array(__DIR__.'/../views'),
	'pagination' => 'pagination::slider-3',

);
