<?php

return array(

    'nameApp'			=> 'SmartMonitor',
    'version'			=> 'V1.9.01',
    'sensorsNode' 		=> 'LS001', //UNICO NODO EN VERSION 1.9.x
    'nameNode'          => 'Banco VOII',
    'sensorOk'			=> 0,
    'sensorDisabled'	=> 1,
    'sensorDetected'	=> 2,
    'hardwareDetected'	=> 3,
    'thresholdAlert'	=> 10,
    'sensorTimeout'		=> 90, // Version 1.9.01

);