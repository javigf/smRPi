<?php

Artisan::add(new PueblaSensores);
Artisan::add(new Controllers);