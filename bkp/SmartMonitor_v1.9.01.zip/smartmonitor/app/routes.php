<?php

app::bind('App\Models\Interfaces\SensorRegistersInterface','App\Models\SensoresRegistros');
app::bind('App\Models\Interfaces\SensorInterface','App\Models\Sensors');
app::bind('App\Models\Interfaces\SensorGroupInterface','App\Models\SensorsGroups');
app::bind('App\Models\Interfaces\MenuInterface','App\Models\GnsMenu');
app::bind('App\Models\Interfaces\GnsMetaWidgetInterface','App\Models\GnsMetaWidget');
app::bind('App\Models\Interfaces\FormatsInterface','App\Models\Formats');
app::bind('App\Models\Interfaces\GrphsFormatInterface','App\Models\GrphsFormat');
app::bind('App\Models\Interfaces\AlertsInterface','App\Models\SensorsAlerts');
app::bind('App\Models\Interfaces\NodeInterface','App\Models\Nodes');
app::bind('App\Models\Interfaces\SensorsRegistersHistoryInterface','App\Models\SensorsRegistersHistory');
app::bind('App\Models\Interfaces\GnsEmailsInterface','App\Models\GnsEmails');


Route::get('login', 'AuthController@showLogin');
Route::post('login', 'AuthController@postLogin');
Route::get('logout','AuthController@logOut');


Route::group(array('before' => 'auth'), function()
{
	Route::get('nodos',function()
	{
		return Redirect::to('/');
	});

	Route::group(array('before' => 'role'), function()
	{	
		Route::post("configuracion",'FormController@postForm');
		Route::post("configWidget",'FormWidgetController@postForm');
		Route::post("configEmail",'FormEmail@postForm');

		Route::post("formUser",'FormUser@postForm');
		Route::post("formUserDel",'FormUser@posDelUser');

		Route::controller('form/{id1}/{id2}', 'FormController');
		Route::controller('formWidget/{id1}/{id2}', 'FormWidgetController');
		Route::controller('usuarios/{acction}/{id?}', 'UserController');

		Route::post("formSensorDel",'SensorController@postDelSensor');
	});
	
	Route::post("ftrTblForm",'FormTableFilter@postForm');
	
	Route::get('content/{id1?}/{id2?}/{id3?}/{id4?}/{id5?}/{id6?}/{id7?}/{id8?}',array('uses' => 'ContentController@gnsContent'));

	Route::controller('busqueda/{type}', 'ItemsDispatcher');
	Route::controller('exportar/{type}', 'ItemsDispatcher');
	Route::controller('alertsDispatcher/{id1}/{id2}', 'AlertsDispatcherController');
	Route::controller('/{id1?}','FrontController');

	Route::get('logout', 'AuthController@logOut');
});