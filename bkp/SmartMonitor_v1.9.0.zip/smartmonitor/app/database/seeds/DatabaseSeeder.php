<?php

class DatabaseSeeder extends Seeder {

	/**
	 * Run the database seeds.
	 *
	 * @return void
	 */
	public function run()
	{
		Eloquent::unguard();

		$this->call('DeleteTableContentSeeder');
 
		$this->call('UserTableSeeder');
		$this->call('MenuTableSeeder');
		$this->call('EmailTableSeeder');
		$this->call('MetaWidgetTableSeeder');
		$this->call('NodeTableSeeder');
		$this->call('SensorsGroupsTableSeeder');
		$this->call('SensorsErrorsTableSeeder');
		$this->call('SensorsStatusTableSeeder');
		$this->call('SensorsTableSeeder');
	}

}
