<?php

class EmailTableSeeder extends Seeder {

	public function run()
	{
		DB::table('gns_emails')->truncate();

		DB::table('gns_emails')->insert(array(
			'host'		=> 'mail.linksolution.com.ar',
			'port'	 	=> 25,
			'username'	=> 'smartmonitor@linksolution.com.ar',
			'password'	=> Crypt::encrypt('123Sm4rt123'),
			'from'		=> 'smartmonitor@linksolution.com.ar',
			'name'		=> 'Alertas Smart Monitor',
			'to'		=> 'smartmonitor@linksolution.com.ar',
			'cc'		=> '',
			'subject'	=> 'Alerta sensor:',
			'active'	=> 0,
			'created_at' 	=> New DateTime,
		));
	}

}
