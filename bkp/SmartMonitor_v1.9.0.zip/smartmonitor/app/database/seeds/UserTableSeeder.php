<?php

class UserTableSeeder extends Seeder {

	public function run()
	{
		
		DB::table('gns_users')->insert(array(
			'first_name'	=> 'Usuario',
			'last_name'		=> 'Administrador',
			'email'			=> 'administrador',
			'username'		=> 'administrator',
			'role_id'		=> 2,
			'password'		=>	Hash::make('sm.m0n1t0r'),
			'created_at' 	=> New DateTime,
		));

		DB::table('gns_users')->insert(array(
			'first_name'	=> 'Operator',
			'last_name'		=> 'Datacenter',
			'email'			=> 'operator',
			'username'		=> 'operator',
			'role_id'		=> 1,
			'password'		=>	Hash::make('operator'),
			'created_at' 	=> New DateTime,
		));

	}

}
