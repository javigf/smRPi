<?php

class NodeTableSeeder extends Seeder {

	public function run()
	{
		DB::table('nodes')->insert(array(
			'id'			=> 'root',
			'description'	=> Config::get('app_globals.nameApp'),
			'created_at' => New DateTime,
		));

		DB::table('nodes')->insert(array(
			'id'			=> Config::get('app_globals.sensorsNode'),
			'description'	=> Config::get('app_globals.nameNode'),
			'parent'		=> 'root',
			'path'			=> 'blue',
			'created_at' => New DateTime,
		));

	}

}
