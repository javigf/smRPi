<?php

class DeleteTableContentSeeder extends Seeder {

	public function run()
	{
		DB::table('gns_meta_widgets')->delete();
		DB::table('gns_menu')->delete();
		DB::table('gns_users')->delete();
		DB::table('gns_emails')->delete();
		DB::table('sensores_registros')->delete();
		DB::table('sensors')->delete();
		DB::table('sensors_errors')->delete();
		DB::table('sensors_groups')->delete();
		DB::table('sensors_status')->delete();
		DB::table('nodes')->delete();

	}
}