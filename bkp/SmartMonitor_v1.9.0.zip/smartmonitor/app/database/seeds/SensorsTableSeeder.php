<?php

class SensorsTableSeeder extends Seeder {

	public function run()
	{
		//TEMEPARURA
		DB::table('sensors')->insert(array(
			'id'			=> 'TEMP01',
			'description'	=> 'Sensor Temperatura 01',
			'min_range'		=> 0,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TE',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TEMP02',
			'description'	=> 'Sensor Temperatura 02',
			'min_range'		=> 0,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TE',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TEMP03',
			'description'	=> 'Sensor Temperatura 03',
			'min_range'		=> 0,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TE',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TEMP04',
			'description'	=> 'Sensor Temperatura 04',
			'min_range'		=> 0,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TE',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TEMP05',
			'description'	=> 'Sensor Temperatura 05',
			'min_range'		=> 0,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TE',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TEMP06',
			'description'	=> 'Sensor Temperatura 06',
			'min_range'		=> 0,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TE',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TEMP07',
			'description'	=> 'Sensor Temperatura 07',
			'min_range'		=> 0,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TE',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TEMP08',
			'description'	=> 'Sensor Temperatura 08',
			'min_range'		=> 0,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TE',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));


		//PUNTO DE CONDENSACION
		DB::table('sensors')->insert(array(
			'id'			=> 'PCON01',
			'description'	=> 'Punto de Condensacion 01',
			'min_range'		=> -5,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PC',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PCON02',
			'description'	=> 'Punto de Condensacion 02',
			'min_range'		=> -5,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PC',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PCON03',
			'description'	=> 'Punto de Condensacion 03',
			'min_range'		=> -5,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PC',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PCON04',
			'description'	=> 'Punto de Condensacion 04',
			'min_range'		=> -5,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PC',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PCON05',
			'description'	=> 'Punto de Condensacion 05',
			'min_range'		=> -5,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PC',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PCON06',
			'description'	=> 'Punto de Condensacion 06',
			'min_range'		=> -5,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PC',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PCON07',
			'description'	=> 'Punto de Condensacion 07',
			'min_range'		=> -5,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PC',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PCON08',
			'description'	=> 'Punto de Condensacion 08',
			'min_range'		=> -5,
			'max_range'		=> 50,
			'min'			=> 0,
			'max'			=> 50,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PC',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));


		//HUMEDAD
		DB::table('sensors')->insert(array(
			'id'			=> 'HDAD01',
			'description'	=> 'Sensor Humedad 01',
			'min_range'		=> 0,
			'max_range'		=> 100,
			'min'			=> 0,
			'max'			=> 100,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HD',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HDAD02',
			'description'	=> 'Sensor Humedad 02',
			'min_range'		=> 0,
			'max_range'		=> 100,
			'min'			=> 0,
			'max'			=> 100,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HD',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HDAD03',
			'description'	=> 'Sensor Humedad 03',
			'min_range'		=> 0,
			'max_range'		=> 100,
			'min'			=> 0,
			'max'			=> 100,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HD',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HDAD04',
			'description'	=> 'Sensor Humedad 04',
			'min_range'		=> 0,
			'max_range'		=> 100,
			'min'			=> 0,
			'max'			=> 100,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HD',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HDAD05',
			'description'	=> 'Sensor Humedad 05',
			'min_range'		=> 0,
			'max_range'		=> 100,
			'min'			=> 0,
			'max'			=> 100,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HD',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HDAD06',
			'description'	=> 'Sensor Humedad 06',
			'min_range'		=> 0,
			'max_range'		=> 100,
			'min'			=> 0,
			'max'			=> 100,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HD',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HDAD07',
			'description'	=> 'Sensor Humedad 07',
			'min_range'		=> 0,
			'max_range'		=> 100,
			'min'			=> 0,
			'max'			=> 100,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HD',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HDAD08',
			'description'	=> 'Sensor Humedad 08',
			'min_range'		=> 0,
			'max_range'		=> 100,
			'min'			=> 0,
			'max'			=> 100,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HD',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));



		//PRESENCIA DE HUMO
		DB::table('sensors')->insert(array(
			'id'			=> 'HUMO01',
			'description'	=> 'Sensor Humo 01',
			'min_range'		=> 0,
			'max_range'		=> 70,
			'min'			=> 0,
			'max'			=> 70,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HM',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HUMO02',
			'description'	=> 'Sensor Humo 02',
			'min_range'		=> 0,
			'max_range'		=> 70,
			'min'			=> 0,
			'max'			=> 70,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HM',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HUMO03',
			'description'	=> 'Sensor Humo 03',
			'min_range'		=> 0,
			'max_range'		=> 70,
			'min'			=> 0,
			'max'			=> 70,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HM',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HUMO04',
			'description'	=> 'Sensor Humo 04',
			'min_range'		=> 0,
			'max_range'		=> 70,
			'min'			=> 0,
			'max'			=> 70,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HM',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HUMO05',
			'description'	=> 'Sensor Humo 05',
			'min_range'		=> 0,
			'max_range'		=> 70,
			'min'			=> 0,
			'max'			=> 70,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HM',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HUMO06',
			'description'	=> 'Sensor Humo 06',
			'min_range'		=> 0,
			'max_range'		=> 70,
			'min'			=> 0,
			'max'			=> 70,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HM',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HUMO07',
			'description'	=> 'Sensor Humo 07',
			'min_range'		=> 0,
			'max_range'		=> 70,
			'min'			=> 0,
			'max'			=> 70,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HM',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'HUMO08',
			'description'	=> 'Sensor Humo 08',
			'min_range'		=> 0,
			'max_range'		=> 70,
			'min'			=> 0,
			'max'			=> 70,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'HM',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));



		//TENSION ALTERNA
		DB::table('sensors')->insert(array(
			'id'			=> 'TALT01',
			'description'	=> 'Tensión Alterna 01',
			'min_range'		=> 0,
			'max_range'		=> 250,
			'min'			=> 0,
			'max'			=> 240,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TA',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TALT02',
			'description'	=> 'Tensión Alterna 02',
			'min_range'		=> 0,
			'max_range'		=> 250,
			'min'			=> 0,
			'max'			=> 240,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TA',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TALT03',
			'description'	=> 'Tensión Alterna 03',
			'min_range'		=> 0,
			'max_range'		=> 250,
			'min'			=> 0,
			'max'			=> 240,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TA',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TALT04',
			'description'	=> 'Tensión Alterna 04',
			'min_range'		=> 0,
			'max_range'		=> 250,
			'min'			=> 0,
			'max'			=> 240,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TA',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TALT05',
			'description'	=> 'Tensión Alterna 05',
			'min_range'		=> 0,
			'max_range'		=> 250,
			'min'			=> 0,
			'max'			=> 240,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TA',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TALT06',
			'description'	=> 'Tensión Alterna 06',
			'min_range'		=> 0,
			'max_range'		=> 250,
			'min'			=> 0,
			'max'			=> 240,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TA',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TALT07',
			'description'	=> 'Tensión Alterna 07',
			'min_range'		=> 0,
			'max_range'		=> 250,
			'min'			=> 0,
			'max'			=> 240,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TA',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'TALT08',
			'description'	=> 'Tensión Alterna 08',
			'min_range'		=> 0,
			'max_range'		=> 250,
			'min'			=> 0,
			'max'			=> 240,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'TA',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));



		//APERTURA DE PUERTA
		DB::table('sensors')->insert(array(
			'id'			=> 'PRTA01',
			'description'	=> 'Puerta 01',
			'min_range'		=> 0,
			'max_range'		=> 0,
			'min'			=> 0,
			'max'			=> 0,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PT',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PRTA02',
			'description'	=> 'Puerta 02',
			'min_range'		=> 0,
			'max_range'		=> 0,
			'min'			=> 0,
			'max'			=> 0,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PT',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PRTA03',
			'description'	=> 'Puerta 03',
			'min_range'		=> 0,
			'max_range'		=> 0,
			'min'			=> 0,
			'max'			=> 0,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PT',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PRTA04',
			'description'	=> 'Puerta 04',
			'min_range'		=> 0,
			'max_range'		=> 0,
			'min'			=> 0,
			'max'			=> 0,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PT',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PRTA05',
			'description'	=> 'Puerta 05',
			'min_range'		=> 0,
			'max_range'		=> 0,
			'min'			=> 0,
			'max'			=> 0,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PT',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PRTA06',
			'description'	=> 'Puerta 06',
			'min_range'		=> 0,
			'max_range'		=> 0,
			'min'			=> 0,
			'max'			=> 0,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PT',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PRTA07',
			'description'	=> 'Puerta 07',
			'min_range'		=> 0,
			'max_range'		=> 0,
			'min'			=> 0,
			'max'			=> 0,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PT',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors')->insert(array(
			'id'			=> 'PRTA08',
			'description'	=> 'Puerta 08',
			'min_range'		=> 0,
			'max_range'		=> 0,
			'min'			=> 0,
			'max'			=> 0,
			'id_error'		=> 0,
			'id_status'		=> 4,
			'refresh'		=> 120,
			'id_group'		=> 'PT',
			'id_node'		=> Config::get('app_globals.sensorsNode'),
			'created_at' 	=> New DateTime,
		));

	}

}