<?php

class SensorsErrorsTableSeeder extends Seeder {

	public function run()
	{
		
		DB::table('sensors_errors')->insert(array(
			'id'			=> '0',
			'description'	=> 'Sensor normal',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '1',
			'description'	=> 'Sensor deshabilitado',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '2',
			'description'	=> 'Nuevo Sensor detectado',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '5',
			'description'	=> 'Sensor alertado',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '10',
			'description'	=> 'Sensor desconectado',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '20',
			'description'	=> 'Error de lectura',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '30',
			'description'	=> 'Valor inválido',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '40',
			'description'	=> 'Error de comunicación',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '50',
			'description'	=> 'Error de Checksum',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '60',
			'description'	=> 'Error de comunicacion con el sensor',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '99',
			'description'	=> 'TEST',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_errors')->insert(array(
			'id'			=> '100',
			'description'	=> 'Sensor fisico deshabilitado',
			'created_at' 	=> New DateTime,
		));

	}

}