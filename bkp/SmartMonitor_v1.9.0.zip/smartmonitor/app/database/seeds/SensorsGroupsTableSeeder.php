<?php

class SensorsGroupsTableSeeder extends Seeder {

	public function run()
	{
		
		DB::table('sensors_groups')->insert(array(
			'id'			=> 'HD',
			'unit'			=> '%',
			'description'	=> 'HUMEDAD',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_groups')->insert(array(
			'id'			=> 'TE',
			'unit'			=> 'ºC',
			'description'	=> 'TEMPERATURA',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_groups')->insert(array(
			'id'			=> 'PC',
			'unit'			=> 'ºC',
			'description'	=> 'P.CONDESACION',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_groups')->insert(array(
			'id'			=> 'HM',
			'unit'			=> 'PPM',
			'description'	=> 'HUMO',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_groups')->insert(array(
			'id'			=> 'TA',
			'unit'			=> 'V',
			'description'	=> 'T.ALTERNA',
			'created_at' 	=> New DateTime,
		));

		DB::table('sensors_groups')->insert(array(
			'id'			=> 'PT',
			'unit'			=> '',
			'description'	=> 'PUERTAS',
			'created_at' 	=> New DateTime,
		));
		
	}

}