<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SmartMonitorTablesV1802 extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		//GNS_USERS
		Schema::create('gns_users',function(Blueprint $table){
			$table->increments('id');
			$table->string('first_name',50);
			$table->string('last_name',50);
			$table->string('email',100);
			$table->string('username',20);
			$table->tinyInteger('role_id')->unsigned();
			$table->string('password',200);

			//Systems
			//$table->timestamps();
			$table->rememberToken();
			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));

			$table->softDeletes();

			$table->unique('email');
			$table->unique('username');

			$table->engine = 'InnoDB';
		});


		//GNS_MENU

		Schema::create('gns_menu',function(Blueprint $table){
			$table->increments('id');
			$table->string('title',25);
			$table->string('subtitle',30);
			$table->string('icon',15);
			$table->string('url',20)->unique();
			$table->tinyInteger('role_id')->unsigned();
			$table->string('description',100)->nullable();
			$table->tinyInteger('order')->unsigned()->unique();

			//Systems
			//$table->timestamps();
			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));

			$table->softDeletes();

			$table->engine = 'InnoDB';
		});


		//GNS_META_WIDGETS
		Schema::create('gns_meta_widgets',function(Blueprint $table){
			$table->increments('id');
			$table->integer('menu_id')->unsigned();
			$table->char('content_id',2);
			$table->string('icon',20);
			$table->string('color',20);
			$table->string('title',40);
			$table->string('subtitle',30);
			$table->boolean('move')->default(true);
			$table->boolean('collapsible')->default(true);
			$table->boolean('close')->default(true);
			$table->tinyInteger('col_lg')->unsigned()->default(12);
			$table->tinyInteger('sequence')->unsigned();
			$table->string('sensors_id',300);
			$table->smallInteger('range')->unsignet();
			$table->char('unit',6);
			$table->tinyInteger('grphstyle')->unsigned()->default(0);
			$table->tinyInteger('grphcolor')->unsigned()->default(0);
			$table->tinyInteger('grphinterp')->unsigned()->default(0);
			$table->smallInteger('refresh')->unsigned()->default(120);
			$table->boolean('modify')->default(true);
			$table->boolean('active')->default(true);

			//Systems
			//$table->timestamps();
			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));
			$table->softDeletes();

			//Foreing Keys
			$table->foreign('menu_id')->references('id')->on('gns_menu');

			$table->engine = 'InnoDB';
		});


		//NODES
		//Schema::dropIfExists('nodes');
		Schema::create('nodes',function(Blueprint $table){
			$table->char('id',6);
			$table->string('description',20);
			$table->char('parent',5)->nullable();
			$table->string('path',20)->nullable();

			//Systems
			//$table->timestamps();
			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));
			$table->softDeletes();

			//Constraits Keys
			$table->primary('id');
			$table->foreign('parent')->references('id')->on('nodes');

			$table->engine = 'InnoDB';
		});


		//SENSORS_GROUPS
		//Schema::dropIfExists('sensors_groups');
		Schema::create('sensors_groups',function(Blueprint $table){
			$table->char('id',3);
			$table->char('unit',3)->nullable();
			$table->string('description',20);

			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));
			$table->softDeletes();

			$table->primary('id');

			$table->engine = 'InnoDB';
		});

		//SENSORS_ERRORS
		//Schema::dropIfExists('sensors_errors');
		Schema::create('sensors_errors',function(Blueprint $table){
			$table->tinyInteger('id')->unsigned();
			$table->string('description',50);

			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));
			$table->softDeletes();

			$table->primary('id');

			$table->engine = 'InnoDB';
		});


		//SENSORS_STATUS
		//Schema::dropIfExists('sensors_errors');
		Schema::create('sensors_status',function(Blueprint $table){
			$table->tinyInteger('id')->unsigned();
			$table->string('description',50);

			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));
			$table->softDeletes();

			$table->primary('id');

			$table->engine = 'InnoDB';
		});


		//SENSORS
		//Schema::dropIfExists('sensors');
		Schema::create('sensors',function(Blueprint $table){
			$table->char('id',6);
			$table->string('description',45);
			$table->smallInteger('min_range')->default(0);
			$table->smallInteger('max_range')->default(0);
			$table->smallInteger('min')->default(0);
			$table->smallInteger('max')->default(0);
			$table->tinyInteger('id_error')->unsigned();
			$table->tinyInteger('id_status')->unsigned()->default(0);
			$table->integer('refresh');
			$table->char('id_group',3);
			$table->char('id_node',6);

			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));
			$table->softDeletes();

			//Constraits Keys
			$table->primary('id');
			$table->foreign('id_group')->references('id')->on('sensors_groups');
			$table->foreign('id_node')->references('id')->on('nodes');
			$table->foreign('id_error')->references('id')->on('sensors_errors');
			$table->foreign('id_status')->references('id')->on('sensors_status');

			$table->engine = 'InnoDB';
		});


		//SENSORES_REGISTROS
		//Schema::dropIfExists('sensores_registros');
		Schema::create('sensores_registros',function(Blueprint $table){
			$table->increments('id');
			$table->char('id_sensor',6);
			$table->decimal('registro',4,1);

			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));

			//Constraits Keys
			$table->foreign('id_sensor')->references('id')->on('sensors');

			$table->engine = 'InnoDB';
		});


		//SENSORES_REGISTROS HISTORICOS
		Schema::create('sensors_registers_history', function(Blueprint $table)
		{
			$table->increments('id');
			$table->char('id_sensor',6);
			$table->decimal('value',4,1);
			$table->string('description',45);
			$table->char('id_group',3);
			$table->smallInteger('min');
			$table->smallInteger('max');
			$table->boolean('alert');
			$table->date('date');
			$table->time('time');

			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));

			/*Index*/
			$table->index('id');
			$table->index('id_sensor');
			$table->index('date');

			$table->engine = 'InnoDB';
		});



		//SENSORES_ALERTS
		//Schema::dropIfExists('sensors_alerts');
		Schema::create('sensors_alerts',function(Blueprint $table){
			$table->increments('id');
			$table->tinyInteger('id_error')->unsigned();
			$table->char('id_sensor',6);
			$table->decimal('registro',4,1);
			$table->smallInteger('min');
			$table->smallInteger('max');
			$table->string('description',100);
			$table->integer('updated')->unsigned()->default(0);
			$table->boolean('checked')->default(false);

			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));
			$table->softDeletes();

			//Constraits Keys
			$table->foreign('id_sensor')->references('id')->on('sensors');
			$table->foreign('id_error')->references('id')->on('sensors_errors');

			$table->engine = 'InnoDB';
		});


		//GNS_EMAILS
		//Schema::dropIfExists('sensors_alerts');
		Schema::create('gns_emails',function(Blueprint $table){
			$table->increments('id');
			$table->string('host',150);
			$table->smallInteger('port');
			$table->char('security',3)->default("");
			$table->string('username',50);
			$table->string('password',500);
			$table->string('from',100);
			$table->string('name',100);
			$table->string('subject',100);
			$table->string('to',1000);
			$table->string('cc',1000);
			$table->boolean('active')->default(true);

			$table->timestamp('created_at');
			$table->timestamp('updated_at')->default(DB::raw("CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP"));
			$table->softDeletes();

			$table->engine = 'InnoDB';
		});

	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('gns_users');
		Schema::drop('gns_meta_widgets');
		Schema::drop('gns_menu');
		Schema::drop('gns_emails');
		Schema::drop('sensors_alerts');
		Schema::drop('sensors_registers_history');
		Schema::drop('sensores_registros');
		Schema::drop('sensors');
		Schema::drop('nodes');
		Schema::drop('sensors_errors');
		Schema::drop('sensors_status');
		Schema::drop('sensors_groups');
	}

}
