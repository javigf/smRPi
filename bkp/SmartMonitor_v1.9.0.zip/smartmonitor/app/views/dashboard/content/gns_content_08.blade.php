@if (count($results)>0)
	<div class="row">
		<div class="col-lg-12">
			<div class="row  margin-top-10">
				<div class="col-lg-offset-1 col-lg-1">
					{{ HTML::image('img/icons/door.png',null, array( 'width' => 30, 'height' => 30,'class' => '' )) }}	
				</div>
				<div class="col-lg-09">
					<h4 class="text-primary"><strong>&nbsp;&nbsp;&nbsp;&nbsp;Apertura de puertas</strong></h4>
				</div>
				
			</div>
			
			@foreach ($results as $key => $element) 
				<div class="text-center col-lg-{{(count((array)$results) < 4)? 12/count((array)$results) : 3}}">
					<br>
					<button id={{$element->id_sensor}} type="button" class="btn btn-lg 
						@if ($element->id_error >= 10)
							btn-warning
						@elseif ($element->val == -10)
							btn-danger
						@else btn-success 
						" @endif
					data-toggle="popover" 
					{{--title="{{($element->val == -10) ?  $element->description : ''}}"" --}}
					title="{{$element->description}}"
					data-placement='bottom' data-trigger='hover' data-content="
						@if ($element->id_error >= 10)
								{{$element->descError}}
						@else 
							La puerta se encuentra {{($element->val == -10) ?  'Abierta' : 'Cerrada'}}						
						@endif	 
					">{{$element->id_sensor}}</button>
					<br><br><br>

				</div>
			@endforeach

		</div>
	</div>
	<script type="text/javascript">
		@foreach ($results as $key => $element)
			@if($element->val == -10 and $element->id_error < 10)
				$('#{{$element->id_sensor}}').popover('show');
			@else
				$('#{{$element->id_sensor}}').popover('hide');
			@endif
		@endforeach
	</script>

@else
	<div class="alert alert-info" role="alert">
		<h2><strong>El sensor de puerta no esta registrado datos</strong></h2>
	</div>
@endif	
