<div class="col-sm-12">
	<div class="tab-content">
		<div class="tab-pane" id="addEdUsers"></div>
		<div class="tab-pane active" id="lstUsers"></div>
	</div>
</div>

{{ HTML::script('js/plugin/select2.min.js'); }} 

<script type="text/javascript">
	
	$(document).ready(function() {
   		pageSetUp();
	});

	@include('dashboard.library.gns_content')
</script>
