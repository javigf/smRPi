@if (count($results)>0)
	<div class="padding-10">
		<div class='col-sm-3 '>
			<form id="side_panel-{{ $contentDiv }}" class="side_panel">
				<div class="toggler" id="renderer_form">
						<input class="quiz-button" type="radio" name="offset-{{ $contentDiv }}" id="stack-{{ $contentDiv }}" value="zero" checked>
						<label class="stack" for="stack-{{ $contentDiv }}">area</label>				
						<input class="quiz-button" type="radio" name="offset-{{ $contentDiv }}" id="value-{{ $contentDiv }}" value="value">
						<label class="value" for="value-{{ $contentDiv }}">valor</label>
					</div>
			</form>
		</div>
		<div class='padding-10 gns_grph_2'>
			<div id="legend-{{ $contentDiv }}" class="grph_legend"></div>
		</div>
		<div id="graph-{{ $contentDiv }}" class="col-lg-12">
			<div id="y_axis-{{ $contentDiv }}"></div>	
			<div id="content-{{ $contentDiv }}" class=".rd-content"></div>
			<div id="x_axis-{{ $contentDiv }}"></div>
		</div>
	</div>
	<style>
		#y_axis-{{ $contentDiv }}{position: absolute;left: -10px;top: 0;bottom: 0;width: 40px;}
		#graph-{{ $contentDiv }}{padding-left: 30px; margin-bottom: -15px}

	</style>
	<script>

		$('#side_panel-{{ $contentDiv }} input').on('change', function() {
			var offset{{ $contentDiv }} = this.value;
			
			if(offset{{ $contentDiv }} == 'value'){
				graph{{ $contentDiv }}.renderer.unstack = true;	
			}else{
				graph{{ $contentDiv }}.renderer.unstack = false;
			}
			
			graph{{ $contentDiv }}.offset = offset{{ $contentDiv }};
			graph{{ $contentDiv }}.render();
		});	

		var palette{{ $contentDiv }} = new Rickshaw.Color.Palette( { scheme: '{{$results->color}}' } );

		var graph{{ $contentDiv }} = new Rickshaw.Graph( {
			element: document.getElementById("content-{{ $contentDiv }}"),
			height: 195,
			min: 'auto',
			renderer: '{{$results->style}}',
			stroke: true,
			preserve: true,
			unstack: false,
			interpolation: '{{$results->interp}}',
			series: [@foreach ($results->map as $keySnsrs => $valueSnsrs)
						{
							color: palette{{ $contentDiv }}.color(),
							data:[ @foreach($valueSnsrs as $keyTms => $value)
									 {x: {{ array_search($keyTms,array_keys((array)$valueSnsrs)) }},y: {{ $value }} },
								@endforeach ],
							name: '{{strtoupper($keySnsrs)}}',
							description: '{{$results->id->$keySnsrs->description}}',
							unit: ' {{$results->id->$keySnsrs->unit}}'
						},
					@endforeach]
		});
		graph{{ $contentDiv }}.render();

		var hoverDetail{{ $contentDiv }} = new Rickshaw.Graph.HoverDetail( {
			graph: graph{{ $contentDiv }},
			formatter: function(series, x, y) {
				var date = '<span class="date">' + format(x) + '</span>';
				var swatch = '<span class="detail_swatch" style="background-color: ' + series.color + '"></span>';
				var content = swatch + series.description + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'  + date + '<strong> Valor: ' + parseInt(y) + series.unit + '</strong>';
				return content; }
		} );

		var legend{{ $contentDiv }} = new Rickshaw.Graph.Legend( {
			graph: graph{{ $contentDiv }},
			element: document.getElementById('legend-{{ $contentDiv }}')

		} );

		var shelving{{ $contentDiv }} = new Rickshaw.Graph.Behavior.Series.Toggle( {
			graph: graph{{ $contentDiv }},
			legend: legend{{ $contentDiv }}
		} );

		var order{{ $contentDiv }} = new Rickshaw.Graph.Behavior.Series.Order( {
			graph: graph{{ $contentDiv }},
			legend: legend{{ $contentDiv }}
		} );

		var highlighter{{ $contentDiv }} = new Rickshaw.Graph.Behavior.Series.Highlight( {
			graph: graph{{ $contentDiv }},
			legend: legend{{ $contentDiv }}
		} );

		var ticksTreatment = 'glow';
		var format = function(n) {

		var map{{ $contentDiv }} = {
				@foreach ($results->map->$keySnsrs as $key => $value)
					{{ array_search($key,array_keys((array)$results->map->$keySnsrs)) }}:'{{ $key }}', 	
				@endforeach
			};
			return map{{ $contentDiv }}[n];
		}

		var xAxis{{ $contentDiv }} = new Rickshaw.Graph.Axis.X({
	  		graph: graph{{ $contentDiv }},
	  		element: document.getElementById('x_axis-{{ $contentDiv }}'),
	  		orientation: 'bottom',
	  		tickFormat: format
		});
		xAxis{{ $contentDiv }}.render();

		var yAxis{{ $contentDiv }} = new Rickshaw.Graph.Axis.Y( {
			graph: graph{{ $contentDiv }},
			orientation: 'left',	
			tickFormat: Rickshaw.Fixtures.Number.formatKMBT,
			pixelsPerTick:40,
			element: document.getElementById('y_axis-{{ $contentDiv }}')
		});
		yAxis{{ $contentDiv }}.render();
		
		var resize{{ $contentDiv }} = function() {
			var widgetBodyWidth{{ $contentDiv }} = $("#graph-{{ $contentDiv }}").width();
			graph{{ $contentDiv }}.configure({
				width: widgetBodyWidth{{ $contentDiv }},
				//height: window.innerHeight * .30
			});
			xAxis{{ $contentDiv }}.render();
			graph{{ $contentDiv }}.render();
			yAxis{{ $contentDiv }}.render();
			
		}

		$( window ).resize(function() {
			resize{{ $contentDiv }}();

			var wt = $("#graph-{{ $contentDiv }}").width();
			if(wt < 400){
				$('#side_panel-{{ $contentDiv }}').css("display", "none");
			}
			else{
				$('#side_panel-{{ $contentDiv }}').css("display", "inline-block");
			}

		});

	</script>
@else
	<div class="alert alert-info" role="alert">
		<h2><strong>Los sensores activos no han registrado datos</strong></h2>
	</div>
@endif