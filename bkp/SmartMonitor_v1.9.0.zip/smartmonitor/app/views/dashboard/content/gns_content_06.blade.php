@if($results->count())
	<table id="content{{ $contentDiv }}" class="table table-striped table-bordered" width="100%">
		<thead>
			<tr>
				<th><h5 class="todo-group-title-dt txt-color-gray"><i class="fa fa-bell"></i></h5></th>
				<th><h5 class="todo-group-title-dt txt-color-red"><i class="fa fa-warning "></i> Alarmas sin Verificar</h5></th>
			</tr>

		</thead>
		<tbody>
			@foreach ($results as $key => $value) 
			<tr>
				<td align="center">
						<h5 class="todo-group-title-dt txt-color-gray"><strong>{{ $value->idAlerta }}</strong></h5>
				</td>
				<td>
					<div class="smart-form">
						<ul id="sortable1" class="todo">
							<li>
								<span class="handle"> 
									<label class="checkbox">
										<input type="checkbox" name="checkbox-inline" value="{{ $value['idAlerta'] }}">
											<i></i> 
									</label> 
								</span>
								<p>
									<strong>{{ $value->description }} ({{ $value->sensor }}) </strong>
									<span class="text-muted txt-color-red"><strong>{{ $value->Error }}</strong></span>
									<span class="date txt-color-red">Ultima actualizacion <strong> {{ $value->Fecha }} {{ $value->Hora }}</strong></span>
								</p>
							</li>
						</ul>
					</div>
				</td>
			</tr>
			@endforeach
		</tbody>
	</table>
@else
	<div class="alert alert-success" role="alert">
		<h2><strong> No se registran alarmas activas</strong></h2>
	</div>
@endif


<script type="text/javascript">

    $(document).ready(function() {
   		pageSetUp();
	});

	@include('dashboard.library.gns_content')

</script>
