<div class="col-sm-12">
	{{ Form::open(array('url' => 'configWidget','id' => 'wgtForm', 'novalidate' => 'novalidate', 'class' => 'register_ajax')) }}		
		<div class="row">
			<div class="col-sm-12">
				<div class="form-bootstrapWizard">
					<br>
					 <ul class="bootstrapWizard form-wizard">
						<li class="active" data-target="#wgtTab1">
							<a href="#wgtTab1" data-toggle="tab"> <span class="step">1</span> <span class="title">Widgets</span> </a>
						</li>
						<li data-target="#wgtTab2">
						   <a href="#wgtTab2" data-toggle="tab"> <span class="step">2</span> <span class="title">Sensores</span> </a>
						</li>
					</ul>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		<div class="tab-content">
			<div class="tab-pane active" id="wgtTab1">
				<br>
				<h3><strong>Widgets </strong> - Configuracion de la ventana</h3>
				
				<div class="col-sm-offset-1 col-sm-9 col-sm-offset-1">
					@include('dashboard.include.gns_select',array('name' => 'wgtId', 'id' => 'wgtId','result' => $results[0], 'onChange' => 'selectOptnWidget', 'disabled' => '', 'multiple' =>''))
				</div>
				<div class="col-sm-2">
					<label class="checkbox-inline">
						{{ Form::Checkbox('wgtActive',1, false, array('id' => 'wgtActive','class' => 'checkbox style-0','disabled' => 'disabled')) }}
						<span><i class='fa  fa-lightbulb-o fa-2x'></i></span>
					</label>
				</div>
				<div class="row">
					<div class="col-sm-7">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-tag fa-lg fa-fw"></i></span>
								{{ Form::text("wgtTitle","Titulo",array("id" => "wgtTitle", "class" => "form-control input-lg",'disabled' => 'disabled')) }}
							</div>
						</div>
					</div>

					<div class="col-sm-5">
						<label class="">
							{{ Form::Radio('wgtIcon','bar-chart-o', false, array('id' => 'wgtIcon_bar-chart-o','class' => 'radiobox','disabled' => 'disabled')) }}
							<span><i class='fa fa-bar-chart-o fa-2x padding-top-10 padding-right-10'></i></span> 
						</label>
						<label class="">
							{{ Form::Radio('wgtIcon','table', false, array('id' => 'wgtIcon_table','class' => 'radiobox','disabled' => 'disabled')) }}
							<span><i class='fa fa-table fa-2x padding-top-10 padding-right-10'></i></span>  
						</label>												
						<label class="">
							{{ Form::Radio('wgtIcon','th-list', false, array('id' => 'wgtIcon_th-list','class' => 'radiobox','disabled' => 'disabled')) }}
							<span><i class='fa fa-th-list fa-2x padding-top-10'></i></span> 
						</label>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-7">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-tag fa-lg fa-fw"></i></span>
								{{ Form::text("wgtSubTitle","Sub Titulo",array("id" => "wgtSubTitle", "class" => "form-control input-lg",'disabled' => 'disabled')) }}
							</div>
						</div>
					</div>
					<div class="col-sm-1">
						<label class="checkbox-inline">
							{{ Form::Checkbox('wgtMove',1, false, array('id' => 'wgtMove','class' => 'checkbox style-0','disabled' => 'disabled')) }}
							<span><i class='fa fa-unlock fa-lg padding-top-10'></i></span>
						</label>
					</div>
					<div class="col-sm-1">
						<label class="checkbox-inline">
							{{ Form::Checkbox('wgtCollapsible',1, false, array('id' => 'wgtCollapsible','class' => 'checkbox style-0','disabled' => 'disabled')) }}
							<span><i class='fa fa-minus fa-lg padding-top-10' ></i></span>
						</label>
					</div>
					<div class="col-sm-1">
						<label class="checkbox-inline">
							{{ Form::Checkbox('wgtClose',1, false, array('id' => 'wgtClose','class' => 'checkbox style-0','disabled' => 'disabled')) }}
							<span><i class='fa fa-times fa-lg padding-top-10'></i></span>
						</label>
					</div>

				</div>
			</div>

			<div class="tab-pane" id="wgtTab2">
				<br>
				<h3><strong>Sensores </strong> - Seleccion de Sensores a incluir</h3>
				<div class="row">
					<div class="col-sm-offset-1 col-sm-10 col-sm-offset-1">
						<div class="form-group">
							@include('dashboard.include.gns_select',array('name' => 'wgtSnsr[]', 'id' => 'wgtSnsr','result' => $results[1]['sensors'], 'onChange' => '','disabled' => 'disabled','multiple' => 'multiple' ))
						</div>
					</div>
				</div>
		    </div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				<div class="form-actions">
					{{ HTML::decode(Form::button('<i class="fa fa-save"></i> <strong>Confirmar</strong>',
						array('id' => 'wgtSubmit','class' => 'btn btn-primary','type' => 'submit','disabled' => 'disabled'))) }}
				</div>
				<div class="col-md-12"><br></div>
			</div>
		</div>

	{{ Form::close() }}                     
</div>
