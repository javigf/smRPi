@section('gns_widgets')
<article>
@foreach ($metaWidget as $widget) 
	<article class="col-sm-12 col-md-12 col-lg-{{ $widget['col_lg'] }} ">
		<div class="jarviswidget jarviswidget-{{ $widget['color'] }}" id="wid-id-Widget{{ $widget['id'] }}" 
		@if ($widget['sensors_id'] != 'NODO')
			data-widget-load="/content/{{ $widget['sensors_id'] }}/{{ $widget['content_id'] }}/{{ $widget['id'] }}/{{ $widget['range'] }}/{{ $widget['grphstyle'] }}/{{ $widget['grphcolor']}}/{{ $widget['grphinterp']}}/{{ $widget['unit'] }}",
		@endif
		data-widget-fullscreenbutton="false"  
		@if ($widget['collapsible'] == 0) data-widget-togglebutton='false' @endif 
		@if ($widget['move'] == 0) data-widget-sortable='false' @endif 
		@if ($widget['close'] == 0) data-widget-deletebutton="false" @endif 
		@if ($widget['refresh'] == 0) data-widget-refreshbutton = "false" @else data-widget-refresh="{{ $widget['refresh'] }}" @endif >
		<header>
			<span class="widget-icon"> <i class="fa fa-{{ $widget['icon'] }}"></i> </span>
			<h2><strong>{{ $widget['title'] }}</strong>&nbsp;<i>{{ $widget['subtitle'] }}</i></h2>	
		</header>
		<div>
			<div class="jarviswidget-editbox">
				<input class="form-control" type="text">
				<span class="note"><i class="fa fa-check text-success"></i> Escriba el nuevo titulo del Weidget y precione el icono grabar</span>
			</div>
			<div class="widget-body no-padding">
			</div>
		</div>
	</article>
@endforeach
</article>
@stop
