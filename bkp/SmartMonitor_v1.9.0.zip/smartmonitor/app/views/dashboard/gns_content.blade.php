@extends('layouts.gns_master')

@section('gns_content')
	
<section id="widget-grid" class="">
	<div class="row">
		@yield('gns_widgets')
	</div>
</section>


@stop


