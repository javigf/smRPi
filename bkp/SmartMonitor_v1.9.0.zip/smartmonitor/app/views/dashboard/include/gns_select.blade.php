<div class="form-group">
	{{ Form::select($name, $result, null,array('id' => $id, 'style' => 'width:100%','class' => '','onChange' => "$onChange(this.id)", $disabled, $multiple)); }}
</div>

{{ HTML::script('js/plugin/select2.min.js'); }}

<script type="text/javascript">

	$(document).ready(function() {
		$("#{{$id}}").select2({
			allowClear : true,
		});
	});

</script>
