<!DOCTYPE html>
<html lang="es-es">
 
<head>
	@include('layouts.gns_head')
</head>
<body class="fixed-header fixed-navigation">
 
	<header id="header">
		@yield('gns_header')
	</header>
	 
	<aside id="left-panel">
		@yield('gns_aside')
	</aside>
	 
	<!-- MAIN PANEL -->
	<div id="main" role="main">
		<!-- RIBBON -->
		<div id="ribbon">
			@yield('gns_ribbon')
		</div>
		<div class="row">
			@yield('gns_headerDash')
		</div>
			
		<div id="content">
			@yield('gns_content')
		</div>
			

	</div>
	 
	@include('layouts.gns_scripts')
	@yield('gns_scripts')

</body>
</html>