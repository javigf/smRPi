@section('gns_aside')

<div class="login-info">
	<span>
		<a href="javascript:void(0);" title="{{ Config::get('app_texts.user') }} {{ Auth::user()->username }}" id="show-shortcut">
			<img src="img/avatars/male.png" alt="me" class="online" /> 

			<i class="fa fa-angle-down"></i>
		</a> 
	</span>
</div>
<nav>
	<ul>
		@foreach ($nav as $menu) 
			<li class={{ $menu['class'] }}>
				<a href="{{ URL::to($menu->url); }}"><i class="fa fa-lg fa-fw  fa-{{ $menu->icon }}"></i> <span class="menu-item-parent">{{ $menu->title }}</span></a>
			</li>
		@endforeach

	</ul>
</nav>
<span class="minifyme"> <i class="fa fa-arrow-circle-left hit"></i> </span>

@stop