@section('gns_header')
	<div id="logo-group">
		<span id="logo"> <img src="img/logo_link.png" alt="SmartMonitor"> </span>

	</div>

	<div class="pull-right">

		<div id="logout" class="btn-header transparent pull-right">
			<span> <a href="logout" title="Cerrar sesion" data-logout-msg="¿Esta segur de cerrar la sesion?.&nbsp;&nbsp; Luego de salir cierre la ventana del navegador"><i class="fa fa-sign-out"></i></a> </span>
		</div>

		<div id="hide-menu" class="btn-header pull-right">
			<span> <a href="javascript:void(0);" title="Ocultar Menu"><i class="fa fa-reorder"></i></a> </span>
		</div>

		<div id="fullscreen" class="btn-header transparent pull-right">
			<span> <a href="javascript:void(0);" onclick="launchFullscreen(document.documentElement);" title="Pantalla Completa"><i class="fa fa-arrows"></i></a> </span>
		</div>

		<ul class="header-dropdown-list hidden-xs">
			<li>
				<a href="#" class="dropdown-toggle" data-toggle="dropdown"> <img alt="" src="img/flags/es.png"> <span> Español </span> <i class="fa fa-angle-down"></i>&nbsp;&nbsp; </a>
				<ul class="dropdown-menu pull-right">
					<li class="active">
						<a href="javascript:void(0);"><img alt="" src="img/flags/es.png"> Español</a>
					</li>
				</ul>
			</li>
		</ul>

	</div>

@stop