@section('gns_headerDash')
<div class="col-lg-12">
	<div class="col-md-7 col-lg-4">
		<h1 class="page-title txt-color-blueDark"><i class="fa-fw fa fa-{{ $menu->icon }}"></i> {{ $menu->title }} <span> {{ $menu->subtitle }}</span></h1>
	</div>
	
		<ul id="sparks" class="col-md-7 col-lg-8">
			<li class="sparks-info">
				<h5>Sensor<span class="txt-color-nuevoSensor"><i class="fa fa-bell fa-1x"></i>&nbsp;Nuevo</span></h5>
			</li>
			<li class="sparks-info">
				<h5>Sensor<span class="txt-color-normal"><i class="fa fa-bell fa-1x"></i>&nbsp;Normal</span></h5>
			</li>
			<li class="sparks-info">
				<h5>Sensor<span class="txt-color-red"><i class="fa fa-bell"></i>&nbsp;Alarmado</span></h5>
			</li>
			<li class="sparks-info">
				<h5>Sensor<span class="txt-color-yellow"><i class="fa fa-bell fa-1x"></i>&nbsp;Error Comunic.</span></h5>
			</li>
			<li class="sparks-info">
				<h5>Sensor<span class="txt-color-purple"><i class="fa fa-bell"></i>&nbsp;Deshabilitado</span></h5>
			</li>
			<li class="sparks-info">
				<h5>Hardware<span class="txt-color-gray"><i class="fa fa-bell"></i>&nbsp;Error</span></h5>
			</li>
		</ul>
	
</div>	
@stop


