{{ HTML::script('js/libs/jquery-2.0.2.min.js'); }}


{{ HTML::script('js/libs/d3.min.js'); }} 

{{ HTML::script('js/libs/jquery-ui-1.10.3.min.js'); }}
    
{{ HTML::script('js/libs/bootstrap.min.js'); }}    
{{ HTML::script('js/libs/SmartNotification.min.js'); }}
{{ HTML::script('js/libs/jarvis.widget.min.js'); }}


{{ HTML::script('js/plugin/bootstrap-progressbar/bootstrap-progressbar.min.js'); }}
{{ HTML::script('js/plugin/jquery.knob.min.js'); }}
{{ HTML::script('js/plugin/superbox/superbox.min.js'); }}

{{ HTML::script('js/plugin/fastclick/fastclick.js'); }}

{{ HTML::script('js/plugin/rickshaw.min.js');}}

{{ HTML::script('js/plugin/bootstrap-wizard/jquery.bootstrap.wizard.min.js'); }}
{{ HTML::script('js/plugin/fuelux/wizard/wizard.js'); }}

{{ HTML::script('js/app.js'); }}

<script type="text/javascript">

	$(document).ready(function() {
		pageSetUp();
	});	

</script>

