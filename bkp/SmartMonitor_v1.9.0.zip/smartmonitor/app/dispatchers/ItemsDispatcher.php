<?php 

use App\Models\Interfaces\SensorsRegistersHistoryInterface;
use App\Models\Interfaces\SensorRegistersInterface;
use App\Models\Interfaces\AlertsInterface;

class ItemsDispatcher extends BaseController 
{

	private $alertsInterface;
	private $sensorRegistersHistory;
	private $sensorRegisters;
	private $getFunction;
	private $parameters = array();
	private $paginate;
	private $sesnsorsId;
	private $values;
	private $doors;
	private $dates;
	private $times;
	
	public function __construct(SensorsRegistersHistoryInterface $sensorRegistersHistory, SensorRegistersInterface $sensorRegisters, AlertsInterface $alertsInterface) 
	{
		$this->alertsInterface = $alertsInterface;
		$this->sensorRegistersHistory = $sensorRegistersHistory;
		$this->sensorRegisters = $sensorRegisters;
	}

	
	public function getIndex($type)
	{
		$method =  "get$type";

		$this->paginate = 20;
		$this->sesnsorsId = Session::get('sensorsId');
		$this->values = Session::get('values');
		$this->doors = Session::get('doors');
		$this->dates = Session::get('dates');
		$this->times = Session::get('times');
		$submit = Session::get('submit');

		
		switch ($type) {
			case 'HSTRYD':
				Session::put('method',$method);
				$this->getFunction = 'getTTable';

				return View::make('dashboard.items.gns_queryTables',$this->$method());
			break;
			case 'HSTRY':
				Session::put('method',$method);
				$this->getFunction = 'getTTable';

				return View::make('dashboard.items.gns_queryTables',$this->$method());
			break;
			case 'ALTR':
				Session::put('method',$method);
				$this->getFunction = 'getTTable';

				return View::make('dashboard.items.gns_queryTables',$this->$method());
			break;
			case 'pdf':
				$this->getFunction = 'getExport';
				$method = Session::get('method');

				$pdf = new PdfExport($this->$method());
				$pdf->body();
			break;
			case 'excel':
				$this->getFunction = 'getExport';
				$method = Session::get('method');			

				$excel = new ExcelExport();
				$excel->getExport($this->$method());
			break;
		}

	}

	public function getHSTRYD()
	{
		$title = 'Registro de sensores del dia';
       	$this->setCondition($this->sensorRegisters,$this->getFunction,'alert',1,array(15,50,15,10,10,25,15),'P',$title);

       	return $this->parameters;
	}

	public function getHSTRY()
	{
		$title = 'Registro historicos de sensores';
    	$this->setCondition($this->sensorRegistersHistory,$this->getFunction,'alert',1,array(15,50,15,10,10,25,15),'P',$title);

       	return $this->parameters;
	}

	public function getALTR()
	{
		$title = 'Listado de Alarmas Generadas';
       	$this->setCondition($this->alertsInterface,$this->getFunction,'checked',0,array(15,50,15,100,10,10,15,25,15),'L',$title);

       	return $this->parameters;
	}

    private function setCondition($interface,$getFunction,$condition,$status,$width,$orientation,$title)
    {
        $this->parameters = array(
        	'items' 		=> $interface->$getFunction($this->paginate,$this->sesnsorsId,$this->values,$this->doors,$this->dates,$this->times),
			'condition' 	=> $condition,
			'status' 		=> $status,
			'width' 		=> $width,
			'orientation' 	=> $orientation,
			'title' 		=> $title,
       	);
    }
}