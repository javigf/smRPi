<?php 

ini_set('max_execution_time', 90);

class PdfExport extends Fpdf
{
    public $items;
    public $condition;
    public $width;
    public $status;
    public $title;
    private $margin;
    private $LeftMargin;

    public function __construct($parameters)
    {
        parent::__construct($parameters['orientation'],'mm','A4');
        $this->items = $parameters['items'];
        $this->condition = $parameters['condition'];
        $this->width = $parameters['width'];
        $this->status = $parameters['status'];
        $this->title = $parameters['title'];

        if ($parameters['orientation'] =='L'){
            $this->margin = 220;
            $this->LeftMargin = 20;
        }
        else{
            $this->margin = 140;
            $this->LeftMargin = 35;
        }

        $this->body();
    }

    public function Header()
    {
        $this->SetLeftMargin($this->LeftMargin-5);
        $path = public_path();
        $path = $path.'/img/logo.png';
        $this->SetFont('Arial','BI',16);
        $this->SetLeftMargin(20);
        $this->Cell(1,10,$this->title, 0, 1, 'L');
        $this->Image($path,$this->margin,10,50);
        $this->Ln(5);
    }

    function Footer()
    {
        $date = date("Y-m-d H:i");
        $this->AliasNbPages();
        $this->SetLeftMargin(30);
        $this->SetY(-15);
        $this->SetFont('Arial','BI',8);
        $this->Cell(15,10,utf8_decode('Página ').$this->PageNo().'/{nb}',0,0,'C');
        $this->Cell($this->margin-16);
        $this->Cell(10,10,$date,0,0,'R');
    }
    
    public function Body()
    {
            $this->AddPage();
            $this->SetFillColor(140,19,19);
        	$this->SetTextColor(255);
        	$this->SetDrawColor(128,0,0);
        	$this->SetLineWidth(.3);
        	$this->SetFont('Arial','B',8.6);

            $this->SetLeftMargin($this->LeftMargin);
            if(!empty($this->items)){
        		$i = 0;
                foreach ($this->items[0] as $key => $value) {
                	if ($this->condition != $key) {
                        if ($key != 'id_group') {
                		  $this->Cell($this->width[$i],7,utf8_decode(strtoupper($key)),1,0,'C',true);
                		  $i++;	
                        }
                	}
                }
               	$this->LN();
                $this->SetTextColor(0);
                $fill = false;
                foreach ($this->items as $key => $values) {

                    if ($values['valor'] < 0 and $values['id_group'] == 'PT'){
                        $values['valor'] = ($values['valor'] == -10) ? 'Abierta' : 'Cerrada';
                    }

                    if ($values[$this->condition] == $this->status) {
                        $this->SetFillColor(242,222,222);
                        $this->SetFont('Arial','IB',8,5);
                        $fill = true;
                    }else{
                        $this->SetFillColor(224,235,255);
                        $this->SetFont('Arial','',8,5);
                    }
                	$i = 0;
                    $this->SetLeftMargin($this->LeftMargin);
                	foreach ($values as $key => $value) {
                		if ($this->condition != $key) {
                            if ($key != 'id_group') {
                                $this->Cell($this->width[$i],7,utf8_decode($value),1,0,'L',$fill);	
                			    $i++;
                            }
                		}
                	}
                	$this->LN();
                	$fill = !$fill;
                }
            }else{
                $this->SetFillColor(239,225,179);
                $this->SetDrawColor(239,225,179);
                $this->SetTextColor(134,100.48);
                $this->SetFont('Arial','IB',12);
                $value =' La consulta no arrojo resultados';
                $this->Cell($this->margin,7,utf8_decode($value),1,0,'L',true);
            }
           $headers = ['Content-Type' => 'aplication/pdf'];
           return Response::make($this->Output(), 200, $headers);
           exit();
    }

 
}