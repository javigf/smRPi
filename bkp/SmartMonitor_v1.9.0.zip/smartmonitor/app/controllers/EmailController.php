<?php 

use App\Models\Interfaces\GnsEmailsInterface;

class EmailController extends BaseController 
{
	private $gnsEmails;
	

	public function __construct(GnsEmailsInterface $gnsEmails)
	{
		$this->gnsEmails = $gnsEmails;
	}


	public function setViewEmail()
	{
		Session::forget('emailId');

		$result = $this->getEmail(1);
		if ($result->count()){
			Session::put('emailId',$result[0]->id);
			return $result[0];
		}
	}
	

	private function getEmail($id)
	{
		return $this->gnsEmails->getEmails($id);	
	}


	public function sendEmail($idSensor, $description, $val,$min,$max,$descErr, $idError,$dt)
	{
		switch (true) {
				case $idError == 1 :
					$content = 'emails.gns_content_1';
					break;
				case $idError == 2 :
					$content = 'emails.gns_content_1';
					break;
				case $idError == 4:
					$content = 'emails.gns_content_4';
					break;
				case $idError == 5:
					$content = ($val == -10)? 'emails.gns_content_6' : 'emails.gns_content_5';
					break;
				case $idError >= 10:
					$content = 'emails.gns_content_10';
					break;
			}

		$email = $this->getEmail(1);

		if ($email->count()) {
			$email = $email[0];

			if ($email->active == 1) {
				$from = array('address' => $email->from, 'name' => $email->name);
				$to = explode(',',$email->to);
				$cc = explode(',',$email->cc);

				$subject = "SmartMonitor sensor alarmado : $description ($idSensor)";
				
			    Config::set('mail.host',$email->host);
			    Config::set('mail.port',$email->port);
			    Config::set('mail.encryption',$email->security);
			    Config::set('mail.username',$email->username);
			    Config::set('mail.password',Crypt::decrypt($email->password));
			   	Config::set('mail.from',$from);

				Mail::send($content, array(
						'sensor' 		=> $idSensor,
						'description' 	=> $description,
						'val'			=> $val,
						'min' 			=> $min,
						'max' 			=> $max,
						'descErr'		=> $descErr,
						'dt'			=> $dt->format('Y-m-d H:i:s'),
					), function ($message) use ($to,$cc,$subject)
					{
						$message->to($to);
						if(!empty($cc[0]))
							$message->cc($cc);
						$message->subject($subject);
				});

				if(count(Mail::failures()) > 0){
					$result = 'ERROR';
				}else{
					$result = 'OK';
				}
			return $result;
			}
		}
	}


	public function testEmail($input,$dt)
	{
		$content = 'emails.gns_content_emailTest';
		$from = array('address' => $input['emailFrom'], 'name' => $input['emailName']);
		$to = explode(',',$input['emailTo']);
		$cc = explode(',',$input['emailCc']);

		$subject = "Prueba de envío de email";
				
		    Config::set('mail.host',$input['emailHost']);
		    Config::set('mail.port',$input['emailPort']);
		    Config::set('mail.encryption',$input['emailSecurity']);
		    Config::set('mail.username',$input['emailUser']);
		   	Config::set('mail.from',$from);
		   	
		   	$emailPassword = (is_null(Input::get('userPassword'))) ? $input['emailPassword'] : '';
			Config::set('mail.password',$emailPassword);

		   	try{
				Mail::send($content, array(
					'dt'	=> $dt->format('Y-m-d H:i:s'),
					), function ($message) use ($to,$cc,$subject)
					{
						$message->to($to);
						if(!empty($cc[0]))
							$message->cc($cc);
						$message->subject($subject);
				});

			return 1;
		} catch (\Exception $e) {
			 return $e;
		}

	}

}
