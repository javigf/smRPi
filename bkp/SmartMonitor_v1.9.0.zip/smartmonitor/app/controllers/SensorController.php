<?php

use App\Models\Interfaces\SensorInterface;

class SensorController extends \BaseController 
{

	protected $sensor;
	protected $alertController;
	protected $emailController;


	public function __construct(SensorInterface $sensor)
	{
		$this->sensor = $sensor;
		$this->AlertController = App::make('AlertsDispatcherController');
		$this->emailController = App::make('EmailController');
	}


	public function postDelSensor()
	{
		
		if(Request::ajax()){
			$idSensor = Input::get('idSensor');
			$descriptionSensor = Input::get('descSensor');

			$result = $this->sensor->deleteSensor($idSensor);
			$this->emailController->sendEmail($idSensor,$descriptionSensor, 0, 0, 0, null, 4, new DateTime());  // Version 1.9.0
			
			if($result == 1){
				$message = Config::get('app_texts.sensor').$idSensor.Config::get('app_texts.sensorDeleteOK');
				$color = '#739E73';
				$icon = 'thumbs-o-up';
			}else{
				$message = Config::get('app_texts.sensorDeleteError').$idSensor;
				$color = '#C46A69';
				$icon = 'thumbs-o-down';
			}
			
			return Response::json(array('message' => $message,'color' => $color,'icon' => $icon));
		}else{
			return Redirect::to('/');
		}
		
	}


	public function listNewSenosor()
	{
		
		$results = $this->sensor->getNewIdSensor();

		$this->AlertController->setAlerts($results);
		exit();
		return $results;
	}
	
}
