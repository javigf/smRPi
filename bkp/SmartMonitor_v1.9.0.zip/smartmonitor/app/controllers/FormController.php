<?php

use App\Models\Interfaces\SensorGroupInterface;
use App\Models\Interfaces\SensorInterface;


class FormController extends BaseController 
{
	private $errorController;
	private $sensoresGrupos;
	private $sensores;
	private $alertsDispatcherController;
	
	public function __construct(SensorGroupInterface $sensoresGrupos, SensorInterface $sensores)
	{
		$this->beforeFilter('auth');
		$this->beforeFilter('role');
		
		$this->sensoresGrupos = $sensoresGrupos;
		$this->sensores = $sensores;
		$this->alertsDispatcherController = App::make('AlertsDispatcherController');
		$this->errorController = new ErrorController();
	}

	public function getIndex($formOptn,$id = null)
	{
		return self::$formOptn($id);
	}


	public function postForm()
	{
		if(Request::ajax()){

			$input = Input::all();

			$reglas = array(
				'ssrId' => 'required',
				'desc_sensor' => 'required|min:5|max:40',
			);

			$validar = Validator::make($input, $reglas);

			if($validar->fails())
			{
				$message = $validar->messages()->first();
				$color = '#C46A69';
				$icon = 'thumbs-o-down';
			}
			else
			{
				$valSensor = explode(';',Input::get('val_sensor'));
				$ssrActive = (is_null(Input::get('ssrActive'))) ? 1 : 0;

				$ssrUpdate = array(
	            	'ssrId' 		=> Input::get('ssrId'),
	            	'desc_sensor' 	=> Input::get('desc_sensor'),
	            	'ssrActive'		=> $ssrActive,
	            	'val_min'		=> $valSensor[0],
	            	'val_max'		=> $valSensor[1],
	        	);

				$update = $this->sensores->updUmbral($ssrUpdate);

				if($update == 1){
					$message ='Sensor: '.$ssrUpdate['ssrId'].', ! Se actualizo correctamente ¡';
					$color = '#739E73';
					$icon = 'thumbs-o-up';

					($ssrActive == Config::get('app_globals.sensorOk')) ? $this->alertsDispatcherController->setAlertNewIdSensor($ssrUpdate['ssrId']):null;
					$this->alertsDispatcherController->configAlertsAllSensors();
				}
				else{
					$message ='NO SE HA REALIZADO La actualización';
					$color = '#C46A69';
					$icon = 'thumbs-o-down';
				}

			}		
			return Response::json(array('message' => $message,'color' => $color,'icon' => $icon));
		}else{
			return Redirect::to('/');
		}
	}


	public function getSelect($node, $multiple = false)
	{
		$results = array('' => '');

		if($multiple == false)
			$results['sensors'] = array( 0 => Config::get('app_texts.sensorSelect'));
		
		$select = $this->sensoresGrupos->getSelectGrp($node);

		if ($select->count() > 0){
		
			foreach ($select as $key => $res) {
				$results['sensors'][$res->grp_desc][$res->id] = ($res->idStatus > 0)? $res->ssr_desc ." (".$res->statusDescription.")": $res->ssr_desc ;
				$results['max_value'][$res->id] = $res->max_range;
				//Version 1.8.2
				$results['min_value'][$res->id] = $res->min_range;
			}
		
		}else{
			$results['max_value'] = array( 0 => 0);
		}

		return $results;
	}

	public function getSelectOptn($id)
	{
		$res = $this->sensores->getSensor($id);		
		$results = ($res->idStatus > 0)? $res->ssrDesc ." (".$res->statusDescription.")": $res->ssrDesc ;

		return Response::json($results);
	}

	
	public function selectOptn($id)
	{
		$results = $this->sensores->getSensor($id);		

		return Response::json($results);
	}


}