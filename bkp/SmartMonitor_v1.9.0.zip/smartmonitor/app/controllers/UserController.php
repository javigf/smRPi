<?php


class UserController extends BaseController 
{
	private $id;
	private $users;


	public function __construct()
	{
		$this->beforeFilter('auth');
		$this->beforeFilter('role');
		
		$this->users = new User();
	}

	public function getIndex($action, $id = null)
	{
		$this->id = $id;
		return self::$action();
	}


	public function getList()
	{
		if(Request::ajax()){
			return View::make('dashboard.items.gns_queryTableUsers')->with('results',$this->users->getAllusers());
		}else{
			return Redirect::to('/');
		}
	}


	public function getAdd()
	{
		if(Request::ajax()){
			return View::make('dashboard.items.gns_queryTableUsersAddEd')->with('results',$this->putLayout($this->users->getIdUser(1),'ADD'));
		}else{
			return Redirect::to('/');
		}
	}


	public function getUser()
	{
		if(Request::ajax()){
			return View::make('dashboard.items.gns_queryTableUsersAddEd')->with('results',$this->putLayout($this->users->getIdUser($this->id),'EDD'));
		}else{
			return Redirect::to('/');
		}
	}


	private function putLayout($results, $acction)
	{
		$result = array();

		foreach ($results[0] as $key => $value) {
			if($acction == 'ADD'){
				$value = null;
			}
			$result[$key] = $value;
		}

		return $result;
	}


}