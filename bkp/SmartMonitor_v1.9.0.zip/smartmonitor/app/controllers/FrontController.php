<?php

use App\Models\Interfaces\MenuInterface;
use App\Models\Interfaces\GnsMetaWidgetInterface;

class FrontController extends BaseController 
{
	private $widgets;
	private $metaWidget;
	private $layoutController;
	private $menuInterface;
	private $nav;
	private $menu;

	public function __construct(MenuInterface $menuInterface, GnsMetaWidgetInterface $metaWidget)
	{
		$this->beforeFilter('auth');
		
		$this->menuInterface = $menuInterface;
		$this->metaWidget = $metaWidget;

		$this->widgets = app::make('WidgetController');
		$this->layoutController = App::make('LayoutController');
	}


	public function getIndex($menuUrl = 'nodos')
	{
		$this->getNav($menuUrl);

		return View::make('dashboard.gns_content',$this->layoutController->getLayout($this->nav,$this->menu))
			->with('metaWidget', $this->gns_Widget($menuUrl));
	}


	private function gns_Widget($menuUrl)
	{
		return $this->widgets->gns_constructWidget($this->metaWidget->getWidgetContruct($this->menu->id));
	}


	private function getNav($menuUrl)
	{	
		$this->nav = $this->menuInterface->getMenu(Auth::user()->role_id);

		foreach ($this->nav as $this->menu) {
			if ($this->menu->url == $menuUrl){
			 $menu = 'active';
			 break;
			}
		}

		if(!isset($menu)){
			$this->getIndex('nodos');
		}
		
	}
}
