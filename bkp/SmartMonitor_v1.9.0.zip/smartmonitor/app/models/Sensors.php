<?php

namespace App\Models;

use App\Models\Interfaces\SensorInterface;
use Eloquent;
use DB;
use LOG;

class Sensors extends Eloquent implements SensorInterface
{

	public function updUmbral($ssrUpdate)
	{
		try{
			$Sensors =  Sensors::where('id', '=', $ssrUpdate['ssrId'])
				->update(array(
					'min' => $ssrUpdate['val_min'],
					'max' => $ssrUpdate['val_max'],
					'description' => $ssrUpdate['desc_sensor'],
					'id_status'	=>	$ssrUpdate['ssrActive'],
					)
				);

			return $Sensors;
		} catch (\Illuminate\Database\QueryException $e) {
			return 0;			
		}
		
	}


	public function getSensor($id)
	{
		$results = Sensors::where('sensors.id','=',$id)
			->join('sensors_groups','sensors_groups.id','=','sensors.id_group')
			->join('sensors_status','sensors.id_status','=','sensors_status.id')
			->where('id_status','<', 3)
			->orderBy('sensors_groups.description')
			->get(array('min_range','max_range','min','max','unit','sensors.description as ssrDesc','id_status as idStatus','sensors_status.description as statusDescription'));

		return $results[0];
	}


	public function getAllSensors()
	{
		$results = Sensors::where('id_status','<', 4)
			->join('sensors_errors','sensors.id_error','=','sensors_errors.id')
			->join('sensors_status','sensors.id_status','=','sensors_status.id')
			->get(array('sensors.id','sensors.description as sensorDescription','sensors.id_error as idError','sensors_errors.description as errorDescription',
				'id_status as idStatus','sensors_status.description as statusDescription'));

		return $results;
	}


	public function setCommError()
	{
		try{
			DB::beginTransaction();
			DB::connection()->disableQueryLog();
			
			$query = DB::statement("update sensors
					set id_error = 60
					where id_group <> 'PT' and id_error < 10 and id_status = 0
					and id not in (select id_sensor from sensores_registros where created_at > DATE_SUB(CURRENT_TIMESTAMP,INTERVAL 90 SECOND))"
				);

			$query = DB::statement("update sensors
					set id_error = 0
					where id_group <> 'PT' and id_error = 60 and id_status = 0
					and id in (select id_sensor from sensores_registros where created_at > DATE_SUB(CURRENT_TIMESTAMP,INTERVAL 90 SECOND))"
				);

			DB::commit();

			return 0;

		} catch (\Illuminate\Database\QueryException $e) {
			DB::rollback();
			return "ERROR AL ACTUALIZAR ESTADO DE LOS SENSORES\n";
		}
	}


	public function setIdError($idSensor,$idError)
	{
		try{
			$Sensors =  Sensors::where('id', '=', $idSensor)
				->update(array(
					'id_error' => $idError)
				);

			return $Sensors;
		} catch (\Illuminate\Database\QueryException $e) {
			return 0;			
		}
		
	}


	public function setNewIdStatus()
	{
		try{
			$Sensors =  Sensors::where('id_status', '=', 3)
				->update(array(
					'id_status' => 2)
				);

			return $Sensors;
		} catch (\Illuminate\Database\QueryException $e) {
			return 0;			
		}
	}


	/*###### Version 1.9.0 ######*/

	public function deleteSensor($idSensor)
	{
		try{
			$result = DB::statement("update sensors s
					inner join sensors_groups sg on id_group = sg.id
				set id_status = 4,
				id_error = 0,
				min = min_range,
				max = max_range,
				s.description = concat('Sensor ', sg.description, ' ',substring(s.id,5))
				where s.id = ?",array($idSensor));

				Log::info("Se borro el sensor: $idSensor");

			return $result;

		}  catch (\Illuminate\Database\QueryException $e) {
			Log::error("Error al borrar sensor: .$idSensor -->".$e);
			
			return -1;
		}
	}


	/*###### Version 1.9.0 ######*/

	public function deleteSensorBatch()
	{
		try{
			DB::beginTransaction();
			DB::connection()->disableQueryLog();
		
			$result = DB::statement("delete sr.* 
				from sensors s inner join sensores_registros sr 
				on s.id = sr.id_sensor
				where id_status = 4");

				//Log::info("deleteSensorBatch  1-> ".$result);

			$result = DB::statement("delete sh.*
				from sensors s inner join sensors_registers_history sh 
				on s.id = sh.id_sensor
				where id_status = 4");

				//Log::info("deleteSensorBatch  2-> ".$result);


			$result = DB::statement("delete sa.*
				from sensors s inner join sensors_alerts sa 
				on s.id = sa.id_sensor
				where id_status = 4");

				//Log::info("deleteSensorBatch  3-> ".$result);


			DB::commit();
			return $result;

		}  catch (\Illuminate\Database\QueryException $e) {
			DB::rollback();
			Log::error("Error al correr proceso deleteSensorBatch --> $e");
			
			$result = $e;
			return $result;
		}
	}


}