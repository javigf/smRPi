<?php

namespace App\Models;

use App\Models\Interfaces\GnsEmailsInterface;
use Crypt;
use Eloquent;
use DB;


class GnsEmails extends Eloquent implements GnsEmailsInterface
{

	public function updEmail($input,$id)
	{
		try{
			$result =  GnsEmails::where('id', '=',$id)
				->update(array(	'host'	=> $input['emailHost'],
						'port'	 	=> $input['emailPort'],
						'security'	=> $input['emailSecurity'],
						'username'	=> $input['emailUser'],
						'from'		=> $input['emailFrom'],
						'name'		=> $input['emailName'],
						'to'		=> $input['emailTo'],
						'cc'		=> $input['emailCc'],
						'active'	=> $input['emailActive'],
			));

			if(isset($input['emailPassword'])){
				$result =  GnsEmails::where('id', '=',$id)
					->update(array('password'	=> Crypt::encrypt($input['emailPassword']),
				));
			}
			
		return $result;
		} catch (\Illuminate\Database\QueryException $e) {
			 return $e;
		}
	}


	public function getEmails($id)
	{
		$results = GnsEmails::where('id','=',$id) 
		->get(array('id','host','port','security','username','password','from','name','subject','to','cc','active'));

		return $results;
	}

}

