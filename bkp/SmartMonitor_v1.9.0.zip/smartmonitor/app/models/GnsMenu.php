<?php 

namespace App\Models;

use App\Models\Interfaces\MenuInterface;
use Project1\Greeting;
use Eloquent;
use DB;


class GnsMenu extends Eloquent implements MenuInterface
{
	//protected $connection = 'local';
	protected $table = 'gns_menu';

	public function getMenu($role)
	{
		$results = GnsMenu::orderby('order')
			->where('role_id','<=',$role)
			->get(array('id','title', 'subtitle', 'icon', 'url'));

		return $results;
	}

}