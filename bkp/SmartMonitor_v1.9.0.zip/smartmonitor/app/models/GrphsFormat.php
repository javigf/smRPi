<?php 

namespace App\Models;

use App\Models\Interfaces\GrphsFormatInterface;

class GrphsFormat  implements GrphsFormatInterface
{
	
	public function getGrphStyle($id)
	{
		$grphStyle = array(
			'',
			'area',
			'line',
			'lineplot',
			'bar',
		);
		
		return $grphStyle[$id];
	}
	
	public function getGrphColor($id)
	{
		$grphColor = array(
			'',
			'spectrum14',
			'colorwheel',
			'cool',
			'spectrum2000',
			'spectrum2001',
			'classic9',
			'smartmonitor10',
			'smartmonitor20',
			'smartmonitor30',
		);

		return $grphColor[$id];
	}

	public function getGrphInterp($id)
	{
		$grphColor = array(
			'',
			'cardinal',
			'linear',
			'step-after',
		);

		return $grphColor[$id];
	}

	public function getColorBootstrap($color)
	{
		$colorBootstrap = array(
			'',
			'default',
			'primary',
			'success',
			'info',
			'warning',
			'danger',
		);

	return $colorBootstrap[$color];
	}

}