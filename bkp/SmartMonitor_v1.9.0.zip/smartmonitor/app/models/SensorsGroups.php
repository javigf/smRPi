<?php

namespace App\Models;

use App\Models\Interfaces\SensorGroupInterface;
use Eloquent;
use DB;


class SensorsGroups extends Eloquent implements SensorGroupInterface
{
	public function getSelectGrp($id_node)
	{
		$results = SensorsGroups::where('id_node','=',$id_node)
			->join('sensors','sensors_groups.id','=','sensors.id_group')
			->join('sensors_status','sensors.id_status','=','sensors_status.id')
			->where('id_Status','<',3)
			->orderBy('sensors_groups.description','asc')
			->orderBy('sensors.id','asc')
			->get(array('sensors_groups.description as grp_desc','sensors.id','sensors.description as ssr_desc','id_status as idStatus','sensors_status.description as statusDescription','max_range','min_range'/*Version 1.8.2*/));

		//print_r(DB::getQueryLog());
		return $results;
	}


	public function getSensorGroup($id = null)
	{
		$results = SensorsGroups::selectRaw('distinct CONCAT(sensors.id_node,sensors_groups.id) name ,sensors.id_node parent, sensors_groups.description alias')
			->join('sensors','sensors_groups.id','=','sensors.id_group')
			->where('id_Status','<',3)
			->get()
			->toArray();

		return $results;	
	}
}
