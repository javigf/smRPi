<?php 

namespace App\Models\Interfaces;

interface NodeInterface
{
	public function getNodes($id = null);
}
