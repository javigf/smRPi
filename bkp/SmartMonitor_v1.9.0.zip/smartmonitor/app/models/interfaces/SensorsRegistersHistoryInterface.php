<?php 

namespace App\Models\Interfaces;

interface SensorsRegistersHistoryInterface
{
	public function getTTable($itemsPerPage,$sensorId,$values,$doors,$dates);

	public function getExport($itemsPerPage,$sensorId,$values,$doors,$dates);

	public function putHistRegisters($ids);

}

