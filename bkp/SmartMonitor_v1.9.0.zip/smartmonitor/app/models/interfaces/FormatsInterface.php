<?php 

namespace App\Models\Interfaces;

interface FormatsInterface
{
	public function getMinute();
	
	public function getHour();

	public function getDay();
}
