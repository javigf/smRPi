<?php 

namespace App\Models\Interfaces;

interface SensorRegistersInterface
{
	public function getNodeSensorsRegisters($id = null);

	public function getLast1Registers($sensorId);

	public function getLastsRegisters($idSensor,$range);

	public function getMaxIdSensor();

	public function getTTable($itemsPerPage,$sensorsId,$values,$doors,$dates,$times);

}



