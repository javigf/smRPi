<?php 

namespace App\Models\Interfaces;

interface MenuInterface
{
	public function getMenu($role);

}
