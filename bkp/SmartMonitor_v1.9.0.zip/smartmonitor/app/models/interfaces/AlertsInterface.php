<?php 

namespace App\Models\Interfaces;

interface AlertsInterface
{
	public function putAlert($sensorId,$val,$min,$max,$descriptioni,$typeAlert);

	public function getTTable($itemsPerPage,$sensorsId,$values,$doors,$dates);

	public function	getExport($itemsPerPage,$sensorsId,$values,$doors,$dates);

	public function checkedAlerts($id);

	public function getUpdated();

	public function updAlert($sensorId,$val,$min,$max,$descriptioni,$updated);

	public function getActiveAlerts();

	public function checkedAlertIdSensor($id,$idError);

	public function checkedAlertNewIdSensor($id);
}

