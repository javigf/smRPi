<?php 

namespace App\Models\Interfaces;

interface GnsMetaWidgetInterface
{
	public function getWidgetContruct($menu_id);

	public function getWidgetTitle();

	public function getWidgetForm($id);

	public function updWidget($wgtUpdate);

	public function setGraphics();

}