<?php 

namespace App\Models\Interfaces;

interface SensorInterface
{
	//public function getNodeSensors($id = null);

	public function getSensor($id);

	public function updUmbral($ssrUpdate);

	public function getAllSensors();

	public function setCommError();

	//public function setNewSensor();

	public function setIdError($idSensor,$idError);

	public function setNewIdStatus();

	public function deleteSensor($idSensor);  // Version 1.9.0
}

