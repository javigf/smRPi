<?php

return array(

    'sensor'            => 'Sensor: ', 
    'user'              => 'Usuario: ',
    'sensorNull'		=> 'No se encuentran sesnores activos', 
    'sensorNoActive'	=> ' (DESHABILITADO)',
    'sensorSelect'		=> 'Seleccione un SENSOR de la lista desplegable',
    'sensorLink'		=> 'Verificando link con los sensors...',
    'sensorDelete'      => 'Borrar sensor',
    'sensorDeleteOK'    => ' borrado corectamente',
    'sensorDeleteError' => 'ERROR al intentar borrar el sensor: ',
    'openDoor'			=> 'Apertura de puerta',
    'emailUpdateOK'		=> 'Se Actualizo la configuracion del correo electronico',
    'emailUpdateNoOk'	=> ' NO SE HA REALIZADO La actualización del correo electronico -- ',
    'emailTestOK'		=> ' Se ha enviado correctamente el email de verificación',
    'emailTestNoOK'		=> ' NO se pudo realizar el envio del email de verificación -- ',
    'integritySensors'  => 'Proceso de correccion de integridad de sensores OK',

);