<?php

use App\Models\Interfaces\GnsEmailsInterface;

class FormEmail extends BaseController 
{
	
	private $gnsEmail;
	private $validar;
	private $data = array();
	private $emailController;

	public function __construct(GnsEmailsInterface $gnsEmail)
	{
		$this->gnsEmail = $gnsEmail;
		$this->emailController = App::make('EmailController');
	}


	public function postForm()
	{
		if(Request::ajax()){

			$input = Input::all();
			$input_aux['emailTo'] = explode(',',str_replace(array(" ","\n","\t","\r","\0","\x0B","<br>","\r\n"),'',Input::get('emailTo')));
			$input_aux['emailCc'] = explode(',',str_replace(array(" ","\n","\t","\r","\0","\x0B","<br>","\r\n"),'',Input::get('emailCc')));
		
			$rules = array(
				'emailFrom' 	=> 'required|min:5|max:100|email',
				'emailName' 	=> 'required|min:3|max:100',
				'emailHost'		=> 'required|min:5|max:150',
				'emailPort'		=> 'required|numeric|min:25|max:65535',
				'emailUser'		=> 'min:5|max:100',
			);


			foreach ($input_aux['emailTo'] as $key => $value) {
				$rules_aux["emailTo.$key"] = 'required|min:5|max:1000|email';
			}
			$validar_aux = Validator::make($input_aux, $rules_aux);
			if ($validar_aux->fails()) {
				$rules["emailTo"] = 'required|min:5|max:1000|email';
			}


			foreach ($input_aux['emailCc'] as $key => $value) {
				$rules_aux["emailCc.$key"] = 'min:5|max:1000|email';
			}
			$validar_aux = Validator::make($input_aux, $rules_aux);
			if ($validar_aux->fails()) {
				$rules["emailCc"] = 'min:5|max:1000|email';
			}

			if(is_null(Input::get('userPassword'))){
				$rules['emailPassword']	= 'required_with:emailUser|min:1|max:50';
			}

			
			$validar = Validator::make($input, $rules);

			$color = '#C46A69';
			$icon = 'thumbs-o-down';			

			if($validar->fails())
			{
				$message = $validar->messages()->first();
			}else{
				$input['emailTo'] = implode(',',$input_aux['emailTo']);
				$input['emailCc'] = implode(',',$input_aux['emailCc']);
				$input['emailActive'] = (!is_null(Input::get('emailActive')))? 1: 0;

				Log::info($input['submitAction']);

				if ($input['submitAction'] == 'emailTest') {
					$results = $this->emailController->testEmail($input,new DateTime());
					$message = Config::get('app_texts.emailTestOK');
					$messageNoOk = Config::get('app_texts.emailTestNoOK');
				
				}elseif($input['submitAction'] == 'emailSubmit'){
					$results = $this->gnsEmail->updEmail($input,Session::get('emailId'));
					$message = Config::get('app_texts.emailUpdateOK');
					$messageNoOk = Config::get('app_texts.emailUpdateNoOk');
				}


				if(is_numeric($results) && $results == 1){
					$color = '#739E73';
					$icon = 'thumbs-o-up';
				}else{
					if(is_object($results)) {
						Log::error($results);
						$results = $results->getMessage();
					}
					$message = 'Error: '.$messageNoOk.$results;
					
				}
			}

			return Response::json(array('message' => $message,'color' => $color,'icon' => $icon));
		}else{
			return Redirect::to('/');
		}
	}

}

	